<?php
define("qaz_wsxedc_qazxc0FD_123K",true);
$phpbb_root_path = './config/';
include($phpbb_root_path."mysql.php");
include($phpbb_root_path."config.php");
include($phpbb_root_path."global.php");
include($phpbb_root_path."function.php");
$sql = new db_sql();
$sql->db_connect();
$sql->db_select();
global $new_list, $newscat_full, $subtin;
header('Content-Type: text/xml; charset=UTF-8', true);
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"."\n";
echo "<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">"."\n";
		echo "<url>\n"; 
		echo "<loc>http://www.baothoidai.com</loc>\n"; 
		echo "<changefreq>weekly</changefreq>\n"; 
		echo "<priority>1.0</priority>\n"; 
		echo "</url>\n";
                
                for($i=1; $i<=count($newscat_full); $i++){	
		$url2="http://www.baothoidai.com/c".$newscat_full[$i]["id"]."-".cut_space_hg(name_ascii($newscat_full[$i]["title"]))."/";
		echo "<url>\n"; 
		echo "<loc>".$url2."</loc>\n"; 
		echo "<changefreq>weekly</changefreq>\n"; 
		echo "<priority>0.5</priority>\n"; 
		echo "</url>\n";
		}
                
                 for($i=1; $i<=count($subtin); $i++){	
		$url2="http://www.baothoidai.com/s".$subtin[$i]["sn_id"]."-".cut_space_hg(name_ascii($subtin[$i]["sn_title"]))."/";
		echo "<url>\n"; 
		echo "<loc>".$url2."</loc>\n"; 
		echo "<changefreq>weekly</changefreq>\n"; 
		echo "<priority>0.5</priority>\n"; 
		echo "</url>\n";
		}
                
		for($i=1; $i<=count($new_list); $i++){	
		$url2="http://www.baothoidai.com/".$new_list[$i]["Url"].".htm";
		echo "<url>\n"; 
		echo "<loc>".$url2."</loc>\n"; 
		echo "<changefreq>weekly</changefreq>\n"; 
		echo "<priority>0.5</priority>\n"; 
		echo "</url>\n";
		}	
   echo("</urlset>\n");
?>