<?php
define("qaz_wsxedc_qazxc0FD_123K",true);
$phpbb_root_path = './config/';
include($phpbb_root_path."mysql.php");
include($phpbb_root_path."config.php");
include($phpbb_root_path."global.php");
include($phpbb_root_path."function.php");
$stintuc 	= array();
$sql = new db_sql();
$sql->db_connect();
$sql->db_select();

// $last_built = date("D, d M Y H:i:s T"); 
$copy_year = "COPYRIGHT".date("Y"); 
$scat = isset($_GET["scat"])   ? $_GET["scat"]   : (isset($_POST["scat"])  ? $_POST["scat"]  : "0");
$select_query = "SELECT sn_id, newscat_id, sn_title FROM subnews WHERE sn_id = ".$scat." LIMIT 1";
    $sql->query($select_query);
    $result =  $sql->fetch_array();
    $catname   = $result['sn_title'];
$query = "   SELECT tieude, Url, anhtin, trichdan, ngaydang 
                    FROM tintuc 
                    WHERE sn_id = ".$scat." 
                    ORDER BY ngaydang DESC,tieude LIMIT 15";
$sql->query($query);
$i = 0;
while($rows = $sql->fetch_array()){
	$i = $i + 1;
	$stintuc[$i]["tieude"]      = $rows["tieude"];
        $stintuc[$i]["Url"]         = $rows["Url"];
	$stintuc[$i]["anhtin"]      = $rows["anhtin"];
        $stintuc[$i]["trichdan"]    = $rows["trichdan"];
	$stintuc[$i]["ngaydang"]    = $rows["ngaydang"];
}
$sql->close();	

header('Content-Type: text/xml; charset=UTF-8', true);
echo "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n";
echo "<rss version=\"2.0\"
	xmlns:content=\"http://purl.org/rss/1.0/modules/content/\"
	xmlns:wfw=\"http://wellformedweb.org/CommentAPI/\"
	xmlns:dc=\"http://purl.org/dc/elements/1.1/\"
	xmlns:atom=\"http://www.w3.org/2005/Atom\"
	xmlns:sy=\"http://purl.org/rss/1.0/modules/syndication/\"
	xmlns:slash=\"http://purl.org/rss/1.0/modules/slash/\">";
 
echo "  <channel>\n"; 
echo "    <title>".$catname." - Báo thời đại - baothoidai.com</title>\n"; 
echo "	  <atom:link href=\"http://www.baothoidai.com".$_SERVER['REQUEST_URI']."\" rel=\"self\" type=\"application/rss+xml\" />";
echo "    <link>http://www.baothoidai.com".$_SERVER['REQUEST_URI']."</link>\n"; 
echo "    <description>".$catname." - Báo thời đại - baothoidai.com</description>\n"; 
echo "    <copyright>$copy_year http://www.baothoidai.com</copyright>\n"; 
echo "    <generator>http://www.baothoidai.com</generator>\n"; 
echo "    <ttl>60</ttl>\n\n"; 
global $dir_imgnews1;
	for($i=1; $i<=count($stintuc); $i++){	
		$url="http://www.baothoidai.com/".$stintuc[$i]["Url"].".htm";
		$trichdan =strip_tags(strimString($stintuc[$i]["trichdan"],10));
		$last_built = "(".gmdate("d/m/Y, h:i, a",$stintuc[$i]["ngaydang"] + 7*3600).")";
		
                echo "<item>\n"; 
		echo "<title>".$stintuc[$i]["tieude"]."</title>\n";
		echo "<link>".$url."</link>\n";
		echo "<description><![CDATA[ <img src='".$dir_imgnews1.$stintuc[$i]["anhtin"]."' alt='".$stintuc[$i]["tieude"]."' width='150'  style='float:left; padding-left:3px; padding-right:3px' title='".$stintuc[$i]["tieude"]."'>".strip_tags($stintuc[$i]["trichdan"])." ]]></description>\n";
		echo "<content:encoded>".$last_built."</content:encoded>\n";
		echo "<dc:creator>baothoidai.com</dc:creator>\n";
		echo "<guid isPermaLink=\"false\">".$url."</guid>\n";
		echo "<wfw:commentRss>http://www.baothoidai.com".$_SERVER['REQUEST_URI']."</wfw:commentRss>\n";
         echo "</item>\n";
		}
   	echo "</channel>\n"; 
	echo "</rss>";
?>