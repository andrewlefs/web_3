<?php
    define('SITEOFF','yes1');
    define('TPL','/new');
    define('TPL_LINK',WEB_DOMAIN.TPL);
    define('WEB_NAME','Hoang Gia INC');

?>