<?php
if (!defined("qaz_wsxedc_qazxc0FD_123K")){
		die("<a href='../index.php'>Login</a> to Web Contents Manager !");
}
$cat 	= array();
$subcat = array();
$faq 	= array();
$intro	= array();
$new 	= array();
$logo 	= array();
$slider	= array();
$yahoo	= array();
$menu_top 	= array();
$currency 	= array();
$ysupport 	= array();
$vote_index	= array();
$newscat 	= array();
$newscat_full 	= array();
$subnews        = array();
$subtin         = array();
$downloadcat = array();
$configuration 	= array();
$sql = new db_sql();
$sql->db_connect();
$sql->db_select();	
$counter = $sql->get_counter();
// Begin Sitemap
$select_query = "SELECT `id`, `title` FROM newscat WHERE `menu` = 1 ORDER BY list_order, title";
$sql->query($select_query);
$i = 0;
while($rows = $sql->fetch_array()){
	$i = $i + 1;
	$menu_top[$i]["id"] 	= $rows["id"];
	$menu_top[$i]["title"] 	= $rows["title"];	
}

$new_event 	= array();
$select_query = "SELECT tinid, tieude, Url, anhtin, trichdan,ngaydang FROM tintuc WHERE tieu_diem = 1 ORDER BY ngaydang DESC,tieude LIMIT 1,4";
$sql->query($select_query);
$i = 0;
while($rows = $sql->fetch_array()){
	$i = $i + 1;
	$new_event[$i]["tinid"] 	= $rows["tinid"];
	$new_event[$i]["tieude"] 	= $rows["tieude"];
        $new_event[$i]["Url"] 		= $rows["Url"];
	$new_event[$i]["anhtin"] 	= $rows["anhtin"];
        $new_event[$i]["trichdan"] 	= $rows["trichdan"];
	$new_event[$i]["ngaydang"] 	= $rows["ngaydang"];
}
// En-Index
$tieu_diem 	= array();
$select_query = "SELECT tinid, tieude, Url, anhtin, trichdan,ngaydang FROM tintuc WHERE tieu_diem = 1 ORDER BY ngaydang DESC,tieude LIMIT 1";
$sql->query($select_query);
$i = 0;
while($rows = $sql->fetch_array()){
	$i = $i + 1;
	$tieu_diem[$i]["tinid"] 	= $rows["tinid"];
	$tieu_diem[$i]["tieude"] 	= $rows["tieude"];
        $tieu_diem[$i]["Url"] 		= $rows["Url"];
	$tieu_diem[$i]["anhtin"] 	= $rows["anhtin"];
        $tieu_diem[$i]["trichdan"] 	= $rows["trichdan"];
	$tieu_diem[$i]["ngaydang"] 	= $rows["ngaydang"];
}
$last_new 	= array();
$select_query = "SELECT tinid, tieude, Url, anhtin, trichdan,ngaydang FROM tintuc WHERE frontpage = 1 ORDER BY ngaydang DESC LIMIT 10";
$sql->query($select_query);
$i = 0;
while($rows = $sql->fetch_array()){
	$i = $i + 1;
	$last_new[$i]["tinid"]          = $rows["tinid"];
	$last_new[$i]["tieude"] 	= $rows["tieude"];
        $last_new[$i]["Url"] 		= $rows["Url"];
	$last_new[$i]["anhtin"] 	= $rows["anhtin"];
        $last_new[$i]["trichdan"] 	= $rows["trichdan"];
	$last_new[$i]["ngaydang"] 	= $rows["ngaydang"];
}
$new_top_view 	= array();
$select_query = "SELECT tinid, tieude, Url, anhtin, trichdan,ngaydang FROM tintuc WHERE frontpage = 1 ORDER BY views DESC LIMIT 5";
$sql->query($select_query);
$i = 0;
while($rows = $sql->fetch_array()){
	$i = $i + 1;
	$new_top_view[$i]["tinid"]       = $rows["tinid"];
	$new_top_view[$i]["tieude"]      = $rows["tieude"];
        $new_top_view[$i]["Url"]         = $rows["Url"];
	$new_top_view[$i]["anhtin"]      = $rows["anhtin"];
        $new_top_view[$i]["trichdan"]    = $rows["trichdan"];
	$new_top_view[$i]["ngaydang"]    = $rows["ngaydang"];
}

$new_139 	= array();
$select_query = "SELECT tinid, tieude, Url, anhtin, trichdan,ngaydang FROM tintuc WHERE frontpage = 1 AND sn_id = 139 ORDER BY ngaydang DESC LIMIT 5";
$sql->query($select_query);
$i = 0;
while($rows = $sql->fetch_array()){
	$i = $i + 1;
	$new_139[$i]["tinid"]       = $rows["tinid"];
	$new_139[$i]["tieude"]      = $rows["tieude"];
        $new_139[$i]["Url"]         = $rows["Url"];
	$new_139[$i]["anhtin"]      = $rows["anhtin"];
        $new_139[$i]["trichdan"]    = $rows["trichdan"];
	$new_139[$i]["ngaydang"]    = $rows["ngaydang"];
}

// En-Index
$new_list 	= array();
$select_query = "SELECT tinid, Url, ngaydang FROM tintuc ORDER BY ngaydang DESC ";
$sql->query($select_query);
$i = 0;
while($rows = $sql->fetch_array()){
	$i = $i + 1;
        $new_list[$i]["Url"]  = $rows["Url"];
}
// End Sitemap

$select_query = "SELECT id, yahooname, nickname FROM yahoo ORDER BY thutu ASC";
$sql->query($select_query);
$i = 0;
while($rows = $sql->fetch_array()){
	$i = $i + 1;
	$yahoo[$i]["id"] 		= $rows["id"];
	$yahoo[$i]["yahooname"] 	= $rows["yahooname"];	
	$yahoo[$i]["nickname"] 		= $rows["nickname"];	
}
// E-News-Event
$select_query = "SELECT id, title FROM newscat WHERE trangchu = 1 ORDER BY list_order, title";
$sql->query($select_query);
$i = 0;
while($rows = $sql->fetch_array()){
	$i = $i + 1;
	$newscat[$i]["id"] 	= $rows["id"];
	$newscat[$i]["title"] 	= $rows["title"];	
}
$select_query = "SELECT id, title FROM newscat ORDER BY list_order, title";
$sql->query($select_query);
$i = 0;
while($rows = $sql->fetch_array()){
	$i = $i + 1;
	$newscat_full[$i]["id"] 	= $rows["id"];
	$newscat_full[$i]["title"] 	= $rows["title"];	
}
$select_query = "SELECT sn_id, sn_title, newscat_id, icon FROM subnews WHERE sn_show=1 ORDER BY sn_title";
$sql->query($select_query);
$i = 0;
while($rows = $sql->fetch_array()){
	$i = $i + 1;
	$subps                      = $rows["sn_id"];
	$subnews[$i]["sn_id"]       = $rows["sn_id"];
        $subnews[$i]["newscat_id"]       = $rows["newscat_id"];
	$subnews[$i]["sn_title"]    = $rows["sn_title"];
	$subnews[$i]["icon"] 	    = $rows["icon"];	
}
$select_query = "SELECT sn_id, sn_title FROM subnews ORDER BY sn_title";
$sql->query($select_query);
$i = 0;
while($rows = $sql->fetch_array()){
	$i = $i + 1;
	$subtin[$i]["sn_id"] 		= $rows["sn_id"];
	$subtin[$i]["sn_title"] 	= $rows["sn_title"];	
}

//get info of download category
$select_query = "SELECT id, title FROM downloadcat WHERE publish=1 ORDER BY list_order, title";
$sql->query($select_query);
$i = 0;
while($rows = $sql->fetch_array()){
	$i = $i + 1;
	$downloadcat[$i]["id"] 		= $rows["id"];
	$downloadcat[$i]["title"] 	= $rows["title"];	
}

//get info of currency
$select_query = "SELECT name, rate FROM currency";
$sql->query($select_query);
$i = 0;
while($rows = $sql->fetch_array()){
	$i = $i + 1;
	$currency[$i]["rate"] 	= $rows["rate"];
	$currency[$i]["name"] 	= $rows["name"];	
}
//get intro Faq
$select_query = "SELECT * FROM faq ORDER BY faqtitle, faqtitle LIMIT 5";
$sql->query($select_query);
$i = 0;
while($rows = $sql->fetch_array()){
	$i = $i + 1;
	$faq[$i]["faqtitle"] 	= $rows["faqtitle"];
	$faq[$i]["faqid"] 	= $rows["faqid"];
}

//get intro menu
$select_query = "SELECT * FROM intro WHERE publish = 1 ORDER BY list_order";
$sql->query($select_query);
$i = 0;
while($rows = $sql->fetch_array()){
	$i = $i + 1;
	$intro[$i]["menu_title"] = $rows["menu_title"];
	$intro[$i]["id"] 	= $rows["id"];
}

//get info of category
$select_query = "SELECT catid, catname FROM cat ORDER BY thutu, catname";
$sql->query($select_query);
$i = 0;
while($rows = $sql->fetch_array()){
	$i = $i + 1;
	$cat[$i]["catid"] 	= $rows["catid"];
	$cat[$i]["catname"] 	= $rows["catname"];	
}
//get info of subcategory
$select_query = "SELECT subcatid, subcatname, catid FROM subcat ORDER BY subcatname";
$sql->query($select_query);
$i = 0;
while($rows = $sql->fetch_array()){
	$i = $i + 1;
	$subcat[$i]["subcatid"] 	= $rows["subcatid"];
	$subcat[$i]["catid"] 		= $rows["catid"];
	$subcat[$i]["subcatname"] 	= $rows["subcatname"];	
}

//get file moi tai len
$select_query = "SELECT id, filename, title FROM download ORDER BY title LIMIT 0, $dew_news";
$sql->query($select_query);
$i = 0;
while($rows = $sql->fetch_array()){
	$i = $i + 1;
	$dewnew[$i]["id"] 		= $rows["id"];
	$dewnew[$i]["title"] 		= $rows["title"];
	$dewnew[$i]["filename"]		= $row["filename"];

}
//get logo of right menu
$select_query = "SELECT logo, link, position FROM doitac WHERE publish = 1 ORDER BY position, thutu";
$sql->query($select_query);
$i = 0;
while($rows = $sql->fetch_array()){
	$i = $i + 1;
	$logo[$i]["logo"] 	= $rows["logo"];
	$logo[$i]["link"]  	= $rows["link"];
	$logo[$i]["position"]  	= $rows["position"];
}
$select_query = "SELECT logo, link, content, position FROM slider WHERE publish = 1 ORDER BY thutu";
$sql->query($select_query);
$i = 0;
while($rows = $sql->fetch_array()){
	$i = $i + 1;
	$slider[$i]["logo"] 		= $rows["logo"];
	$slider[$i]["content"] 		= $rows["content"];
	$slider[$i]["position"] 	= $rows["position"];
	$slider[$i]["link"]  		= $rows["link"];
}
// get vote
$select_query = "SELECT name FROM votes WHERE type=1";
$sql->query($select_query);
$row = $sql->fetch_array();
$cauhoi = $row['name'];
		
$select_query = "SELECT id ,name FROM votes WHERE type=0 ORDER BY vote_order";		
$sql->query($select_query);
	
$i=0;
while($row = $sql->fetch_array()){
	$i=$i+1;
	$vote_index[$i]["id"] = $row['id'];
	$vote_index[$i]["name"] = $row['name'];
}
$linkseo 	= array();
$select_query = "SELECT * FROM linkseo WHERE publish = 1 ORDER BY list_order";
$sql->query($select_query);
$i = 0;
while($rows = $sql->fetch_array()){
	$i = $i + 1;
	$linkseo[$i]["id"] 		= $rows["id"];
	$linkseo[$i]["keyword"] 	= $rows["keyword"];
	$linkseo[$i]["linkweb"] 	= $rows["linkweb"];
}
$sql->close();
?>