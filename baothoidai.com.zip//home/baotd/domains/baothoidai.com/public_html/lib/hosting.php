<?php
if (!defined("qaz_wsxedc_qazxc0FD_123K")){		
		die("<a href='../index.php'>Trang ch&#7911;</a>");
}
$block_detail 	= array();
$block			= array();
$sql = new db_sql();
$sql->db_connect();
$sql->db_select();

if(isset($_GET["id"]) && $HTTP_GET_VARS["Webdesign"] == "hosting"){
	$id = isset($_GET["id"]) && is_numeric($_GET["id"]) ? $_GET["id"] : 0;

	$select_query = "SELECT blockname, blockimg, blockin, content FROM blockinfo WHERE blockid = $id";
	$sql->query($select_query);							
	if($row = $sql->fetch_array()){
		$block_detail["blockname"] 	= $row["blockname"];
		$block_detail["blockimg"] 	= $row["blockimg"];
		$block_detail["blockin"] 	= $row["blockin"];
		$block_detail["content"] 	= $row["content"];
	}
	
	$select_query = "SELECT blockid, blockname FROM blockinfo WHERE blockid<>$id";		
	$sql->query($select_query);							
	$i=0;
	while($row = $sql->fetch_array()){
		$i = $i+1;
		$block[$i]["blockid"] = $row["blockid"];
		$block[$i]["blockname"] = $row["blockname"];
	}
	$sql->close();		
}

function detail_hosting(){
	global $block_detail, $dir_imgblocks1, $catname, $block ;	
	if(count($block_detail)>0){
	echo "<TABLE border=0 cellPadding=8 cellSpacing=1 width='98%'>";
	echo "<TBODY>";
	echo "<TR>";
	echo "<TD>";
	echo "<TABLE border=0 height=78 width='100%'>";
	echo "<TBODY>";
	echo "<TR>";
	echo "<TD height=23 vAlign=top width='98%' align='left' class='title_16' >".$block_detail["blockname"]."";
	echo "</TD>";
	echo "</TR>";
	echo "<TR>";
	echo "<TD height=125 align='left' width='98%'>";
	echo "<p align='justify'>";
	if($block_detail["blockimg"]!='')
	echo "<img border='0' src='".$dir_imgblocks1.$block_detail["blockimg"]."' align='left'>";
	echo $block_detail["content"]."</p>";
	echo "<p align='right'>";
	echo "<a href='index.php?Webdesign=contact'>[Đăng ký]</a>&nbsp;";
	echo "<a href='javascript:history.back()'>[Về trang trước]</a>&nbsp;";
	echo "<a href='javascript:print()'>[Tạo trang in]</a>";
	echo "</TD>";
	echo "</TR>";
	echo "<TR>";
	echo "<TD height=22 width='100%'>&nbsp;</TD>";
	echo "</TR>";
	echo "</TBODY></TABLE>";
	echo "</TD></TR></TBODY></TABLE>";		
	}else 
	echo "<br><font face='Arial, Tahoma' size='2'>Không có dữ liệu bạn yêu cầu !</font>";		
}
?>