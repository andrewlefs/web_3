<?php
if (!defined("qaz_wsxedc_qazxc0FD_123K")){		
		die("<a href='../index.php'>Home</a>");
}
$username_invalid 	= false;
$login_invalid 		= false;
$password_invalid 	= false;
$msg = '';
if($_SERVER['REQUEST_METHOD']=='POST'){
	$arrUserInfo =& $_POST;
	if(!eregi('^[a-zA-Z0-9_]+$', $arrUserInfo["user"]))
		$username_invalid = true;
	if($arrUserInfo["user"]=='' || strlen($arrUserInfo["user"]) < 4)
		$username_invalid = true;
	if($arrUserInfo["pass"]=='' || strlen($arrUserInfo["pass"]) < 6)
		$password_invalid = true;
	if(!$username_invalid && !$password_invalid) {
		$sql = new db_sql();
		$sql->db_connect();
		$sql->db_select();
		$sSQL = "SELECT `memberid`,`user`,`pass`,`fullname`,`phone`,`workphone`,`address`,`email`,`signdate`
				 FROM member
				 WHERE user='".$arrUserInfo["user"]."'";
		$result = $sql->query($sSQL);
		while($row = mysql_fetch_assoc($result))
		if(count($row) > 0){
			if($row["pass"]==$arrUserInfo["pass"]){
				$Auth["memberid"] 	= $row["memberid"];
				$Auth["user"] 		= $row["user"];
				$Auth["fullname"] 	= $row["fullname"];
				$Auth["phone"] 		= $row["phone"];
				$Auth["workphone"] 	= $row["workphone"];
				$Auth["address"] 	= $row["address"];
				$Auth["email"] 		= $row["email"];
				$Auth["signdate"] 	= $row["signdate"];
				$ref = ($_SESSION["ref"]!='')?$_SESSION["ref"]:"/download.htm";
				header("Location: $ref");
				exit;
			}
		}
		$sql->close();
		$login_invalid = true;
	} 
	if($password_invalid)
		$msg='Vui lòng nhập Mật khẩu chính xác';
	if($username_invalid)
		$msg='Vui lòng nhập Tên đăng nhập chính xác';
	if($login_invalid)
		$msg='Tên đăng nhập hoặc Mật khẩu không chính xác';
}
function login_body(){
		echo "<h1>Thông tin đăng nhập</h1>";
		echo "<div class='cont_detail_news'>";
		echo "<p>Vui lòng đăng nhập để được sử dụng tài nguyên trên website, nếu chưa có tài khoản vui lòng <strong><a href='".WEB_DOMAIN."/dang-ky.htm'>đăng ký tại đây</a></strong></p>";
		echo "<form class='contactform' action='' method='post' onSubmit='return CheckLoginForm()' name='frmLogin' enctype='application/x-www-form-urlencoded'>";
		if($msg!=''){
		echo "<div class='errmsg'>";
		echo $msg;
		echo "</div>";
		}
		echo "<div class='login_1'>";
		
		echo "<div class='login_0'>";
		echo "	<div class='login_2'>Tên đăng nhập</div>";
		echo "	<div class='login_3'>";
        echo "	<input type='text' name='user' class='loginforminput'/>";
        echo "	</div>";
		echo "</div>";
		
		echo "<div class='login_0'>";
        echo "	<div class='login_2'>Mật khẩu</div>";
        echo "	<div class='login_3'>";
        echo "	<input type='password' name='pass' class='loginforminput'/>";
        echo "	</div>";
        echo "</div>";
        
        echo "<div class='login_0'>";
        echo "	<div class='login_2'></div>";
        echo "	<div class='login_3'>";
      	echo "	<input type='submit' class='btn_login' name='Submit' value='Đăng nhập' />";
       	echo "	<input type='reset'  class='btn_login' name='Reset' value='Nhập lại' />";
        echo "</div>";
        echo "</div>";
        
        echo "</div>";
      	echo "</form>";
      	
        echo "</div>";
}
?>