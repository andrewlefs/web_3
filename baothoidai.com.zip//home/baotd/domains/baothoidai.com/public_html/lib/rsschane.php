<?php
if (!defined("qaz_wsxedc_qazxc0FD_123K")){		
		die("<a href='../index.php'>Home pages</a>");
}
$title = array(	"rsschane" => "Baothoidai.com và các kênh tin RSS Feeds", );


function sub_menu(){
                    echo '<div  id="ngaythang">'.get_date(date('Ymd'),$f='f').'</div>';
                    }

function publish(){
global $newscat_full, $subnews;	
    if(count($newscat_full)>0){
    for($i=1; $i<=count($newscat_full); $i++) {
        echo '<tr>
                <td width="100"><p align="right">
                <a href=""><img src="/new/images/nc-rss.png" border="0" height="13" width="35"></a></p>
                </td>
                    <td style="text-align: left;padding-left:10px">
                    <font color="#666666" size="2">
                    <a style="font-family: Arial; font-weight: bold;" href="#">'.$newscat_full[$i]["title"].'</a> ( <a href="#">'.$newscat_full[$i]["title"].'</a>)</font>
                    </td>
              </tr>';                                                                                                                  
            if(count($subnews)>0){
                for($j=1; $j<=count($subnews); $j++) {
                    if($subnews[$j]["newscat_id"]==$newscat_full[$i]["id"]){                               
                     // /rss/'.$scat.'-'.cut_space(name_ascii($catname)).'.rss
                        echo '<tr>
                            <td width="100">
                                <p align="right"><a href="/rss/'.$subnews[$j]["sn_id"].'-'.cut_space(name_ascii($subnews[$j]["sn_title"])).'.rss" id="ctl00_IDContent_rptCat_ctl16_imglink">
                                 <img src="/new/images/nc-rss.png" border="0" height="13" width="35"></a>
                                </p>
                            </td>
                            <td style="text-align: left;padding-left:10px">
                                <font color="#666666" size="2">
                                    <a style="font-family: Arial; font-weight: bold;" href="/rss/'.$subnews[$j]["sn_id"].'-'.cut_space(name_ascii($subnews[$j]["sn_title"])).'.rss"> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; '.$subnews[$j]["sn_title"].'</a> (<a href="/rss/'.$subnews[$j]["sn_id"].'-'.cut_space(name_ascii($subnews[$j]["sn_title"])).'.rss">http://www.baothoidai.com/rss/'.$subnews[$j]["sn_id"].'-'.cut_space(name_ascii($subnews[$j]["sn_title"])).'.rss</a>)
                                </font>
                            </td>
                        </tr>';
                    }
                }
            }
    }
    }

}
?>