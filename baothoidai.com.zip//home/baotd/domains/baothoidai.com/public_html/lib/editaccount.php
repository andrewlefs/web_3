<?php
if (!defined("qaz_wsxedc_qazxc0FD_123K")){		
		die("<a href='../index.php'>Trang ch&#7911;</a>");
}
if($Auth["memberid"] < 1){
	header("Location: index.php?module=login");
	exit;
}
$arrUserInfo = array();
$arrUserInfo =& $Auth;
//Var
$old_password_invalid 			= false;
$new_password_invalid 			= false;
$confirm_new_password_invalid 	= false;
$email_existing 				= true;
$firstname_invalid 				= false;
$email_invalid 					= false;
$email_existing					= false;
$address_invalid 				= false;
$phone_invalid 					= false;
$workphone_invalid 				= false;
$msg='';
$msg2='';
if($_SERVER['REQUEST_METHOD']=='POST'){
	$action = $_GET["action"];
	if($action=="edit"){
		$arrUserInfo =& $_POST;
		$sql = new db_sql();
		$sql->db_connect();
		$sql->db_select();

		if($arrUserInfo["email"]=='' || !check_valid_email($arrUserInfo["email"])){
			$email_invalid = true;
		}else{
			$sSQL = "SELECT memberid
					FROM member
					WHERE email='".$arrUserInfo["email"]."' AND memberid!=".$Auth["memberid"];
			$sql->query($sSQL);
			if($sql->num_rows()>0)
				$email_existing = true;
		}

		if($arrUserInfo["fullname"]=='')
			$firstname_invalid = true;

		if($arrUserInfo["phone"]=='')
			$phone_invalid = true;
			
		if($arrUserInfo["workphone"]=='')
			$workphone_invalid = true;

		if($arrUserInfo["address"]=='')
			$address_invalid = true;
		
		if(!$firstname_invalid && !$email_invalid && !$email_existing && !$address_invalid && !$phone_invalid && !$workphone_invalid) {
			$sSQL = "UPDATE member SET `fullname`='".$arrUserInfo["fullname"]."', `phone`='".$arrUserInfo["phone"]."',`workphone`='".$arrUserInfo["workphone"]."', `address`='".$arrUserInfo["address"]."', `email`='".$arrUserInfo["email"]."' WHERE memberid=".$Auth["memberid"];
			$sql->query($sSQL);
			$msg = 'Cập nhật tài khoản thành công';
		} else {
			if($email_invalid)
				$msg = "Xin vui lòng nhập E-mail hợp lệ.";			
			
			if($email_existing)
				$msg = "E-mail này đang được sử dụng. Xin vui lòng chọn E-mail khác.";
			
			if($phone_invalid)
				$msg = "Xin vui lòng nhập số Điện thoại của bạn.";
				
			if($address_invalid)
				$msg = "Xin vui lòng nhập Địa chỉ của bạn.";
			
			if($firstname_invalid)
				$msg = "Xin vui lòng nhập Họ tên của bạn.";
		}
		$sql->close();
	} else if($action=="changepass"){

		$sql = new db_sql();
		$sql->db_connect();
		$sql->db_select();
		$oldpass = $_POST["oldpass"];
		$newpass = $_POST["newpass"];
		$renewpass = $_POST["renewpass"];
		if($oldpass=='' || strlen($oldpass) < 6){
			$old_password_invalid = true;
			$oldpass = '';
			$newpass = '';
			$renewpass = '';
		} else {
			$sSQL = "SELECT pass
					FROM member
					WHERE memberid=".$Auth["memberid"];
			$result = $sql->query($sSQL);
			if($sql->num_rows()>0){
				while($row = mysql_fetch_assoc($result))
				if($row["pass"]!=$oldpass)
					$old_password_invalid = true;
			}
		}
		if($newpass=='' || strlen($newpass) < 6){
			$new_password_invalid = true;
			$newpass = '';
			$renewpass = '';
		}
		
		if($newpass!=$renewpass){
			$confirm_new_password_invalid = true;
			$arrUserInfo["pass"] = '';
			$arrUserInfo["repass"] = '';
		}
		if(!$old_password_invalid && !$new_password_invalid && !$confirm_new_password_invalid){
			$sSQL = "UPDATE member SET `pass`='".$newpass."' WHERE memberid=".$Auth["memberid"];
			$sql->query($sSQL);
			$msg2 = 'Mật khẩu đã được thay đổi';
			$oldpass = '';
			$newpass = '';
			$renewpass = '';
		} else {
				
			if($confirm_new_password_invalid)
				$msg2 = "Nhập lại mật khẩu mới không chính xác";
			
			if($new_password_invalid)
				$msg2 = "Mật khẩu mới không hợp lệ";
				
			if($old_password_invalid)
				$msg2 = "Mật khẩu cũ không chính xác";		
		}
		$sql->close();
	}
}
?>