<?php
if (!defined("qaz_wsxedc_qazxc0FD_123K")){		
		die("<a href='../index.php'>Home</a>");
}
	$res = array();	
	$message = '';
	$w = '';
	$sql = new db_sql();
	$sql->db_connect();
	$sql->db_select();	
	$i=0;
	if($HTTP_GET_VARS["hweb"]=="tags" || $HTTP_POST_VARS["hweb"]=="tags"){
		if(!isset($_GET["text"])){		
			$text_search 	= convert_font($_POST["text_search"],2);
		}
		else{
			$text_search	= isset($_GET["text"]) ? stripslashes($_GET["text"]) : "";
		}
		if($text_search != "" ){
			$w.=" tieude like '%".$text_search."%' ";
			$w.=" OR tags like '%".$text_search."%'";
			$w.=" OR trichdan like '%".$text_search."%'";
			if(is_numeric($text_search))
				$w.=" OR ngaydang like '%".$text_search."%'";
		}

		if($w!=""){	
			$select_query = "SELECT s.tinid as tinid, s.Url as Url, s.tieude as tieude, s.anhtin as anhtin, 
				s.ngaydang as ngaydang, s.trichdan as trichdan, s.tags as tags FROM tintuc as s 
				WHERE ".$w." ORDER BY s.ngaydang";
			$sql->query($select_query);
			$n = $sql->num_rows();
			$new_per_page = is_numeric($new_per_page) && $new_per_page>0 ? $new_per_page : 1;
			$position_page = isset($HTTP_GET_VARS["position_page"]) && is_numeric($HTTP_GET_VARS["position_page"])  ? $HTTP_GET_VARS["position_page"]:1; 
			$from = $position_page ==1 ? 0 : (($new_per_page*$position_page)- $new_per_page);
			$count_rows = $n;	
			$pages_number = ceil($count_rows/$new_per_page);
			$search_query = "SELECT s.tinid as tinid, s.Url as Url, s.tieude as tieude, s.anhtin as anhtin, 
				s.ngaydang as ngaydang, s.trichdan as trichdan, s.tags as tags FROM tintuc as s 
				WHERE ".$w." ORDER BY s.ngaydang LIMIT $from, $new_per_page";
			$sql->query($search_query);
			$i=0;
			while($row = $sql->fetch_array()){
				$i=$i+1;			
				$res[$i]["tinid"] 	= $row["tinid"];
				$res[$i]["Url"] 	= $row["Url"];
				$res[$i]["tieude"] 	= $row["tieude"];
				$res[$i]["anhtin"] 	= $row["anhtin"];
				$res[$i]["ngaydang"] 	= $row["ngaydang"];
				$res[$i]["trichdan"] 	= $row["trichdan"];
			}
			if($count_rows==0)
					$message = $message."tags";
		}
		else{
			if($w=="")			
				$message = $message."tags.";						
			
		}
	}
	$title = array(	"tags" => " Tags ".stripslashes($text_search)."",
 	);

function sub_menu(){
                echo '<div class="div-hot">
                    <img class="imgnew_hot" border="0" src="http://img.hoanggia.net/icon_notice.png">
                    </div>';
                    echo '<div  class="sub-menu-i">';
                    echo"<ul >";
                    echo"<li class='bg-hat'><a href='".WEB_DOMAIN."/s107-cac-su-kien-noi-bat-2012/' title='Các sự kiện nổi bật 2012'>Các sự kiện nổi bật 2012</a></li>";
                    echo"<li class='bg-hat'><a href='".WEB_DOMAIN."/s108-thuong-tet-2013/' title='Thưởng Tết 2013'>Thưởng Tết 2013</a></li>";
                    echo"</ul>";
                    echo '</div>';
                    
                    
                    
                    }
function publish(){
    global $res, $dir_imgnews1, $position_page, $pages_number, $text_search, $message, $n , $cat_search;
    
        echo '<div id="left_content" class="ml10">';
       if($message=="" && $n > 0){ 
        echo '<div class="tieudetintuc"><h1>Tags: '.stripslashes($text_search).'</h1></div>';
        if(count($res)>0){
			for($i=1; $i<=count($res); $i++){
			$anhtin = $res[$i]["anhtin"] <> "" ? "<img class='img130' src='".$dir_imgnews1.$res[$i]["anhtin"]."' alt='".$res[$i]["tieude"]."' title='".$res[$i]["tieude"]."'>" : '';
		echo '  <div class="cottintuc">
                        <div class="immg">';
             	echo    $anhtin;
                echo '  </div>
                        <div class="ndtintuc">
                        <div class="tentintuc"><a href="'.WEB_DOMAIN.'/'.$res[$i]["Url"].'.htm"><b>'.$res[$i]["tieude"].'</b></a></div>
                	<span>'.strip_tags(strimString($res[$i]["trichdan"],80)).'</span>   
                        </div></div>';
                    }
		}
            echo '<div class="clear"></div>';
            if($pages_number >1 ){
                    echo '<div class="paging" style="margin-top:15px;">';
                            pages_HG("/tags/key-".htmlentities(urlencode($text_search))."/trang-",$position_page,$pages_number);
                    echo "</div>";
            }
       }
   else { 
             echo '<div class="tieudetintuc"><h1>Không có kết quả phù hợp: '.stripslashes($text_search).'</h1></div>';  
   }         
echo '</div>';
echo '<div id="right_content" class="mr10">
        	<div class="cotright ">
            	<div class="tieuderight cot1">Danh mục sách</div>
             <div id="linklk" class="linklk">
                    	<ul>
                            <li><a href="#">Kiến thức làm giàu</a></li>
                            <li><a href="#">Máy tính bảng giá rẻ có ôi?</a></li>
                            <li><a href="#">Kiến thức kinh tế</a></li>
                            <li><a href="#">Kiến thức khoa học</a></li>
                            <li><a href="#">Kiến thức danh nhân</a></li>
                            <li><a href="#">Kiến thức tôn giáo</a></li>
                             <li><a href="#">Cao học kinh tế</a></li>
                             <li><a href="#">Đang chơ những tấm lòng hảo tâm</a></li>
                             <li  style="border-bottom:none;"><a href="#">Khác!!!</a></li>
                        </ul>
                    </div>   
            </div>
        	<div class="cotright ">
            	<div class="tieuderight cot1">Tài liệu kĩ năng</div>
             <div id="linklk" class="linklk">
                    	<ul>
                            <li><a href="#">Kĩ năng tự học hiệu quả</a></li>
                            <li><a href="#">Kĩ năng bán hàng</a></li>
                            <li><a href="#">Kĩ năng thương lượng</a></li>
                            <li><a href="#">Kĩ năng giải quyết vấn đề</a></li>
                            <li><a href="#">Kĩ năng tổ chức công việc</a></li>
                            <li><a href="#">Kĩ năng thuyết trình</a></li>
                             <li><a href="#">Kĩ năng tư duy  chiến lượng</a></li>
                             <li><a href="#">Kĩ năng giao tiếp</a></li>
                             <li style="border-bottom:none;"><a href="#">Kĩ năng làm việc theo nhóm</a></li>
                        </ul>
                    </div>   
            </div><!--cotright-->
            <div class="cotright">
            	<div class="tieuderight">Thông tin từ BeRichMart</div>
                <div class="noidungright">
                	<div class="tintuc"><a href="#">Mua hàng an toàn trên BeRich-Mart</a><div>Bạn muốn mua hàng và được giao hàng tận nơi?</div></div>
                    <div class="tintuc"><a href="#">Mua hàng an toàn trên BeRich-Mart</a><div>Bạn muốn mua hàng và được giao hàng tận nơi?</div></div>
                    <div class="tintuc"><a href="#">Mua hàng an toàn trên BeRich-Mart</a><div>Bạn muốn mua hàng và được giao hàng tận nơi?</div></div>
                    <div class="xemthem"><a href="#">Xem thêm</a></div>
                </div>
            </div><!--cotright-->
        </div><!--rightcontent-->';   
} 

?>