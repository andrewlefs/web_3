<?php
if (!defined("qaz_wsxedc_qazxc0FD_123K")){		
		die("<a href='../index.php'>Trang ch&#7911;</a>");
}
if($HTTP_POST_VARS["Webdesign"] == "maps")
?>