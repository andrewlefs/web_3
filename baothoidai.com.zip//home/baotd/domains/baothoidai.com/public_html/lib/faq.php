 <?php
if (!defined("qaz_wsxedc_qazxc0FD_123K")){
		die("<a href='index.php'>Login</a> to Web Contents Manager !");}
	$faq = array();
	$sql = new db_sql();
	$sql->db_connect();
	$sql->db_select();		
	$count_rows = $sql->count_rows("faq");
	$pages_number = ceil($count_rows/$faq_per_page);
	$position_page = isset($_GET["position_page"]) ? $HTTP_GET_VARS["position_page"] : 1;	
	$from = $position_page ==1 ? 0 : (($faq_per_page*$position_page)- $faq_per_page);
	$select_query = "SELECT faqid, faqtitle, question, review FROM faq ORDER BY faqtitle LIMIT $from, $faq_per_page";
	$sql->query($select_query);
	$i=0;
	while($row = $sql->fetch_array()){
		$i=$i+1;
		$faq[$i]["faqid"] 	 = $row["faqid"];
		$faq[$i]["faqtitle"] = $row["faqtitle"];
		$faq[$i]["question"] = $row["question"];
		$faq[$i]["review"]	 = nl2br($row["review"]);			
	}
	$sql->close();
function browser_faq(){
	global $faq, $pages_number, $position_page;
	if(count($faq)>0){
	echo "<h1>HỎI ĐÁP THIẾT KẾ WEB</h1>";	
	echo "<TABLE width='100%' border=0 cellpadding='0' cellspacing='0'>";
	echo "<TBODY>";	
	echo "<TD height=23 vAlign=top width='100%'>";
	for($i=1; $i<=count($faq); $i++){
	echo "<table width='100%'  border='0' cellspacing='2' cellpadding='2'>";
	echo "<tbody>";
	echo "<tr>";
	echo "<td class='review_book'><a href='".WEB_DOMAIN."/hoi-dap/".$faq[$i]["faqid"]."/".cut_space(name_ascii($faq[$i]["faqtitle"])).".htm'><strong>".$faq[$i]["faqtitle"]."</strong></a></td>";
	echo "</tr>";
	echo "<tr>";
	echo "<td class='review_book'><strong>Hỏi</strong>: ".$faq[$i]["question"]."</td>";
	echo "</tr>";
	echo "<tr>";
	echo "<td class='review_book'><strong>&#272;áp</strong>: ".$faq[$i]["review"]."<p align='right'>";
	echo "<a  href='".WEB_DOMAIN."/hoi-dap/".$faq[$i]["faqid"]."/".cut_space(name_ascii($faq[$i]["faqtitle"])).".htm'><font color='#0000ff'>.:Chi tiết <img src='images/forward.gif' height='12' border='0'></font></a></td>";
	echo "</tr>";
	echo "</tbody>";
	echo "</table>";
	if($i<count($faq)) echo "<hr size=1>";
	}
	echo "</TD>";
	echo "</TR>";
	echo "<TR>";
	echo "<TD><br>";
	echo "</TD>";
	echo "</TR>";
	if($pages_number >1 ){
		echo "<TR>";
		echo "<TD class='browser' height=20 vAlign=middle bgcolor='whitesmoke'>";
		pages_browser("index.php?Webdesign=faq&position_page=",$position_page,$pages_number);
		echo "</TD>";
		echo "</TR>";
	}	
	echo "</TBODY></TABLE><br>";	
	}
	else echo "<br><font face='Arial, Tahoma' size='2'>Không có dữ liệu bạn yêu cầu !</font>";
}
?>