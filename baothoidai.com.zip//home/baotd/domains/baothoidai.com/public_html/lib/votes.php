<?php
if (!defined("qaz_wsxedc_qazxc0FD_123K")){
		die("<a href='../index.php'>Home Page</a>!");
	}
	$vote = array();
	if($HTTP_GET_VARS["Webdesign"] == "votes")
	{
		$sql = new db_sql();
		$sql->db_connect();
		$sql->db_select();
		
		//update votes into table votes
		if(isset($_POST['choice_vote'])){
			$choice_vote = $_POST['choice_vote'];			
			$select_query = "SELECT votes FROM votes WHERE id = $choice_vote";
			$sql->query($select_query);
			$row = $sql->fetch_array();
			$v = $row['votes'] + 1;		
			$update_query = "UPDATE votes SET votes = $v WHERE id = $choice_vote";
			$sql->query($update_query);
			
		}
		//end upadate
		$re_sum_votes = sum_votes()!=0 ? sum_votes() : 1;
		$select_query = "SELECT name FROM votes WHERE type=1";
		$sql->query($select_query);
		$row = $sql->fetch_array();
		$cauhoi = $row['name'];
		
		$select_query = "SELECT name, votes FROM votes WHERE type=0 ORDER BY vote_order";		
		$sql->query($select_query);
		
		$i=0;
		while($row = $sql->fetch_array()){
			$i=$i+1;
			$vote[$i]["name"] = $row['name'];
			$vote[$i]["votes"] = $row['votes'];
			$vote[$i]["percent"] = round(($row['votes'] * 100)/$re_sum_votes,2);
			
		}		
		$sql->close();
	}
	
	function sum_votes(){
		global $sql;
		$select_query = "SELECT sum(votes) as sum_of_votes FROM votes WHERE type = 0";
		$sql->query($select_query);
		$row = $sql->fetch_array();
		return $row['sum_of_votes'];		
	}
	function result_votes(){ 
		global $vote, $cauhoi;
		echo "<table width='450' align='center' cellspacing='0'>";
		echo "<tr>";
		echo "<td valign='top' bgcolor='#d4d0c8'>";
		echo "<table bgcolor='whitesmoke'  width='100%' cellpadding='2' cellspacing='1' >";
		echo "<tr bgcolor='#FFFFFF' class='header_table'>";
		echo "<td colspan='4' valign='top'><div align='center'><font face='Tahoma, Arial, Verdana'><strong>KẾT QU&#7842; TH&#258;M D&Ograve; &Yacute; KIẾN KHÁCH HÀNG</strong></font><br>";
		echo "</div></td>";
		echo "</tr>";
		echo "<tr bgcolor='#FFFFFF' class='header_table'>";
		echo "<td colspan='4' valign='top' > ";
		echo "<span class='style5'><br>";
		echo $cauhoi;
		echo " </span></td>";
		echo "</tr>";
		echo "<tr bgcolor='#CCCCCC' class='book_tr'>";
		echo "<td bgcolor='whitesmoke'><div align='center' class='style5'><strong>&Yacute; kiến</strong></div></td>";
		echo "<td   colspan='2' bgcolor='whitesmoke'><div align='center' class='style5'><strong>S&#7889; phiếu</strong></div></td>";
		echo "<td bgcolor='whitesmoke'><div align='center' class='style5'><strong>T&#7927; l</strong>&#7879;</div></td>";
		echo "</tr>";
		for($i=1; $i<=count($vote); $i++){
		echo "<tr bgcolor='#FFFFFF' class='book_tr'>";
		echo "<td width='68%'   class='book_tr_left' ><span class='style5'>";
		echo $vote[$i]['name'];
		echo "</span></td>";
		echo "<td   colspan='2'>";
		echo "<div align='center' class='style5'>";
		echo $vote[$i]['votes'];
		echo "</div></td>";
		echo "<td width='16%' align=right><span class='style5'>";
		echo $vote[$i]['percent']." %";
		echo "</span>";
		echo "<div align='right' class='style5'></div>";
		echo "<div align='right' class='style5'></div></td></tr>";
		}
		echo "<tr class='book_tr'>";
		echo "</tr>";		
		echo "</table></td>";
		echo "</tr>";
		echo "</table>";
	}
?>