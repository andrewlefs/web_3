<?php
if (!defined("qaz_wsxedc_qazxc0FD_123K")){		
		die("<a href='../index.php'>Trang ch&#7911;</a>");
}
$tieude = $lang['home_title'];

$title = array(	"index" => "$tieude",
	 	);
function sub_menu(){
//                echo '<div class="div-hot">
//                    <img class="imgnew_hot" border="0" src="http://img.hoanggia.net/icon_notice.png" alt="Thông báo">
//                    </div>';
                    echo '<div  class="sub-menu-i">';
                    echo"<ul >";
                    echo"<li class='bg-hat'><a href='".WEB_DOMAIN."/s107-cac-su-kien-noi-bat-2012/' title='Các sự kiện nổi bật 2012'>Các sự kiện nổi bật 2012</a></li>";
                    // echo"<li class='bg-hat'><a href='".WEB_DOMAIN."/s108-thuong-tet-2013/' title='Thưởng Tết 2013'>Thưởng Tết 2013</a></li>";
                    echo"<li class='bg-hat'><a href='".WEB_DOMAIN."/chu-tich-nuoc-chuc-mung-tet-quy-ty-nam-201.htm' title='Chủ tịch nước chúc mừng Tết Quý Tỵ năm 201'>Văn Thư chúc Tết Quý Tỵ - 2013</a></li>";
                    echo"</ul>";
                    echo '</div>';
                    
                    
                    
                    }
function tieu_diem(){
   global $tieu_diem, $dir_imgnews1;                 
   for($i=1; $i<=count($tieu_diem); $i++){ 
   echo '  <div id="tin">
            <div><a href="'.WEB_DOMAIN.'/'.$tieu_diem[$i]["Url"].'.htm" title="'.$tieu_diem[$i]["tieude"].'">'.$tieu_diem[$i]["tieude"].'</a></div>
            <span>'.strip_tags(cut_str($tieu_diem[$i]["trichdan"],250)).'</span>
            <img  src="'.$dir_imgnews1."_thumbs/".$tieu_diem[$i]["anhtin"].'_t.jpg" title="'.$tieu_diem[$i]["tieude"].'" alt="'.$tieu_diem[$i]["tieude"].'"/>
            </div>'; 
   }
}
function last_new(){
   global $last_new ;                 

    echo '   <ul>';
       for($i=1; $i<=count($last_new); $i++){  
            echo '<li><a class="bullet4" href="'.WEB_DOMAIN.'/'.$last_new[$i]["Url"].'.htm">'.cut_str($last_new[$i]["tieude"],70) .'</a></li>';
            }          
    echo '</ul>';
   
}
function listnew_cat(){
	global $newscat, $dir_imgnews1, $subnews;
	$newindex 	= array();
        $sub_news       = array();
	$tin_cungloai	= array();
	$sql = new db_sql();
	$sql->db_connect();
	$sql->db_select();
        $select_query = "SELECT sn_id, newscat_id, sn_title FROM subnews ORDER BY sn_title";
        $sql->query($select_query);
        while($rows = $sql->fetch_array()){
                $subnews[$rows["sn_id"]] = cut_space(name_ascii($rows["sn_title"]));
        }
	for($i=1; $i<=count($newscat); $i++){
		unset($newindex);
		$dk = $newscat[$i]['id'];
		$sql_query = "  SELECT count(*) as c 
                                FROM tintuc 
                                WHERE  newscat_id = $dk  
                                AND frontpage = 1";
		$sql->query($sql_query);
		$row = $sql->fetch_array();
		$c = $row['c'];
		$select_query = "   SELECT tieude, Url, trichdan, newscat_id, sn_id, ngaydang, anhtin 
                                    FROM tintuc 
                                    WHERE frontpage = 1 AND newscat_id = $dk  
                                    ORDER BY ngaydang DESC,tieude LIMIT 1";
		$sql->query($select_query);
                    $k = 0;
                    while($rows = $sql->fetch_array()){
                            $k = $k + 1;
                            $newindex[$k]["Url"] 	= $rows["Url"];
                            $newindex[$k]["trichdan"] 	= $rows["trichdan"];
                            $newindex[$k]["tieude"] 	= $rows["tieude"];	
                            $newindex[$k]["anhtin"] 	= $rows["anhtin"];
                            }
		$select_query = "   SELECT tieude, Url FROM tintuc 
                                    WHERE frontpage = 1 AND newscat_id = $dk  
                                    ORDER BY ngaydang DESC,tieude LIMIT 5";
		$sql->query($select_query);
                    $k = 0;
                    while($rows = $sql->fetch_array()){
                            $k = $k + 1;
                            $tin_cungloai[$k]["tieude"] 	= $rows["tieude"];	
                            $tin_cungloai[$k]["Url"]            = $rows["Url"];
                            }
                    
		if($c >0){

            echo '<div class="cot">';
            for($j=1; $j<=count($newindex); $j++){
                echo '<div class="tieude">
                                <div class="ten"><a href="'.WEB_DOMAIN.'/c'.$newscat[$i]["id"].'-'.cut_space_hg(name_ascii($newscat[$i]["title"])).'/" title="'.$newscat[$i]["title"].'">'.$newscat[$i]["title"].'</a></div>';
                                if(count($subnews)>0){
                                echo '<ul>';
                                    for($h=1; $h<=count($subnews); $h++) {
                                    if($subnews[$h]["newscat_id"]==$newscat[$i]["id"]){                 
                                    echo '<li><a href="'.WEB_DOMAIN.'/s'.$subnews[$h]["sn_id"].'-'.cut_space(name_ascii($subnews[$h]["sn_title"])).'/" name="category" id="42">'.$subnews[$h]["sn_title"].'</a></li>';
                                    }
                                    }
                                    echo '</ul>';
                                    }
                            echo '</div>';
                echo '<div class="noidung">
                    	<div class="leftnoidung">
                            <div class="imgnoidung"><img src="'.$dir_imgnews1.$newindex[$j]["anhtin"].'" alt="'.$newindex[$j]["tieude"].'" /></div>
                            <div class="chitiet">
                            	<div><a href="'.WEB_DOMAIN.'/'.$newindex[$j]["Url"].'.htm" title="'.$newindex[$j]["tieude"].'"><b>'.$newindex[$j]["tieude"].'</b></a></div>
                                <span>'.$newindex[$j]["trichdan"].'</span>
                            </div>
                        </div>';
                }
           if(count($tin_cungloai)>0){
                        echo '<div class="rightnoidung">
                        	<ul>';
                        for($j=1; $j<=count($tin_cungloai); $j++){
                            	echo '<li><a href="'.WEB_DOMAIN.'/'.$tin_cungloai[$j]["Url"].'.htm" title="'.$tin_cungloai[$j]["tieude"].'">'.$tin_cungloai[$j]["tieude"].'</a></li>';
                                }
                            echo '</ul>
                        </div>
                    </div>';
                }
                else{}
		echo "</div>\n";
		}
	}
	$sql->close();
}
?>