﻿<?php
if (!defined("qaz_wsxedc_qazxc0FD_123K")){		
		die("<a href='../index.php'>Trang ch&#7911;</a>");
}

function list_file(){
	if($HTTP_GET_VARS["Webdesign"] == "Mauthietke"){
	Echo "Tải file";
}	
}
?>