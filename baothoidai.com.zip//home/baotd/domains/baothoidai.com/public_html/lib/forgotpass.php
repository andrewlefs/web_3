<?php
if (!defined("qaz_wsxedc_qazxc0FD_123K")){		
		die("<a href='../index.php'>Trang ch&#7911;</a>");
}
$email_invalid 			= false;
$email_notexisting 			= false;
$msg = '';
$status = 0;
if($_SERVER['REQUEST_METHOD']=='POST'){
	$email = strip_tags(addslashes($_POST["email"]));

	if($email=='' || !check_valid_email($email))
		$email_invalid = true;
		
	if(!$email_invalid) {
		$sql = new db_sql();
		$sql->db_connect();
		$sql->db_select();
		$sSQL = "SELECT `user`,`pass`,`fullname`
				 FROM member
				 WHERE email='".mysql_escape_string($email)."'";
		$result = $sql->query($sSQL);
		$num_rows = mysql_num_rows($result);
		if($num_rows > 0){
			ob_start();
			while($row = mysql_fetch_assoc($result))
			include "tpl/forgotpass_letter.tpl";
			$mail_content = ob_get_contents();
			ob_end_clean();
			$headers  = 'MIME-Version: 1.0' . "\r\n";
			$headers .= 'Content-type: text/html; charset=utf-8'."\r\n";	
			// Additional headers
			$headers .= 'To: '. $row["fullname"] . "\r\n";
			$headers .= 'From: Công Ty Cổ Phần Phân Phối Năm Châu <info@namchau.vn>' . "\r\n";
			mail($email, "Thong tin tai khoan", $mail_content, $headers);
			/*
			require_once 'lib/phpmailer/class.phpmailer.php';
			//Create mail object
			$mail    = new PHPMailer();
			$mail->From     = 'info@namchau.vn';
			$mail->FromName = "Công Ty Cổ Phần Phân Phối Năm Châu";
			$mail->Subject  = "Thong tin tai khoan";
			$mail->MsgHTML($mail_content);
			$mail->AddAddress($email, $row["fullname"]);
			$mail->Send();
			var_dump($mail->ErrorInfo);
			*/
			$status = 1;
		} else {
			$email_notexisting = true;
		}
		$sql->close();
	} 
	
	if($email_invalid)
		$msg='Vui lòng nhập E-mail chính xác';
	if($email_notexisting)
		$msg='Không tìm thấy E-mail này trong hệ thống';
}
?>