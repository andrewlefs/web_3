<?php
if (!defined("qaz_wsxedc_qazxc0FD_123K")){		
		die("<a href='../index.php'>Home pages</a>");
}

$advs = array();
$sql = new db_sql();
$sql->db_connect();
$sql->db_select();
if(isset($_GET["id"]) && $HTTP_GET_VARS["Webdesign"] == "adv"){
	$id = isset($_GET["id"]) && is_numeric($_GET["id"]) ? $_GET["id"] : 0;
		$select_query = "SELECT views FROM linkseo WHERE id=".$id;
		$sql->query($select_query);
		$rows = $sql->fetch_array();
		$views = intval($rows["views"]);
		$views++; 
		$update_query = "UPDATE linkseo SET views=$views WHERE id=$id";
			if(!$sql->query($update_query))
			echo 'Loi Update!';	
	$select_query = "SELECT id, keyword, linkweb FROM linkseo WHERE id = $id";
	$sql->query($select_query);	
	if($row = $sql->fetch_array()){
									$advs["id"] 		= $row["id"];
									$advs["keyword"] 	= $row["keyword"];
									$advs["linkweb"] 	= $row["linkweb"];
									}
	$sql->close();	
}
function adv_url(){
	global $advs;	
	print "<script>";
    print " self.location='http://".$advs["linkweb"]."';";
    print "</script>";
}
?>