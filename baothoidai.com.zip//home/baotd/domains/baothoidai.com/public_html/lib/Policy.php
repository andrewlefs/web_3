<?php
if (!defined("qaz_wsxedc_qazxc0FD_123K")){		
		die("<a href='../index.php'>Home pages</a>");
}
$title = array(	"Policy" => "Privacy Policy | dieu khoan su dung", );


function sub_menu(){
                    echo '<div  id="ngaythang">'.get_date(date('Ymd'),$f='f').'</div>';
                    }

?>