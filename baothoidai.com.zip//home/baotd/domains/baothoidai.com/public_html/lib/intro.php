<?php
if (!defined("qaz_wsxedc_qazxc0FD_123K")){		
		die("<a href='../index.php'>Home pages</a>");
}
$intro_detail 	= array();
$sql = new db_sql();
$sql->db_connect();
$sql->db_select();
if(isset($_GET["id"]) && $HTTP_GET_VARS["Webdesign"] == "intro"){
	$id = isset($_GET["id"]) && is_numeric($_GET["id"]) ? $_GET["id"] : 0;
	$select_query = "SELECT title, content FROM intro WHERE id = $id";
	$sql->query($select_query);							
	if($row = $sql->fetch_array()){
		$title 						= $row["title"];
		$intro_detail["title"] 		= $row["title"];
		$intro_detail["content"] 	= $row["content"];
	}
	$title = array(	"intro" => "$title - Hoang Gia INC",
 	);
	$sql->close();
}
function header_intro(){
	global $intro_detail, $dmail, $lang;	
	if(count($intro_detail)>0){
		echo "<h1>".$intro_detail["title"]."</h1>";
		echo "".$intro_detail["content"]."<br/>";
		echo "<div class='trangin'>";
		echo "<a class='quaylai fl kc_c' href='javascript:history.back(-1)'>".$lang['_PREVIOUS_PAGE']."</a>";
			echo "<a href='mailto:".$dmail."' class='mail fl kc_c' title='E-Mail'>".$lang['_SEND_MAIL']."</a>";
			echo "<a href='javascript:print()' class='fl print kc_c' title='Print'>".$lang['_PRINT_PAGE']."</a>";
			echo "<a href='#' class='fl ontop kc_c' title='On Top'>".$lang['_ON_TOP']."</a>";
		echo "</div>";		
	}else echo $lang['_MESSAGE_NO_DATA'];		
}
?>