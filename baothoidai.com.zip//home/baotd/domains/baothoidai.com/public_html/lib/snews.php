<?php
if (!defined("qaz_wsxedc_qazxc0FD_123K")){		
		die("<a href='../index.php'>Home</a>");
}
$news = array();
$view = array();
$sub_news   = array();
$check = 0;
global $new_per_page, $newscat_full;
$scat     = isset($_GET["scat"])   ? $_GET["scat"]   : (isset($_POST["scat"])  ? $_POST["scat"]  : "0");
if($hweb == "snews"){
	$sql = new db_sql();
	$sql->db_connect();
	$sql->db_select();	
		$select_query = "SELECT tinid FROM tintuc WHERE sn_id = $scat";
		$sql->query($select_query);
		$count_rows = $sql->num_rows();
	$pages_number = ceil($count_rows/$new_per_page);
	$position_page = isset($_GET["position_page"]) ? $HTTP_GET_VARS["position_page"] : 1;	
	$from = $position_page ==1 ? 0 : (($new_per_page*$position_page)- $new_per_page);
	$select_query = "SELECT tinid, tieude, Url, trichdan, ngaydang, anhtin FROM tintuc";
	if($scat > 0)
	$select_query .= " WHERE sn_id = ".$scat." ORDER BY ngaydang DESC LIMIT $from, $new_per_page";
	$sql->query($select_query);
	$i = 0;
	while($rows = $sql->fetch_array()){
		$ngaydang = $rows["ngaydang"];
		$i = $i + 1;
		$view[$i]["tinid"] 	= $rows["tinid"];
		$view[$i]["tieude"] 	= $rows["tieude"];
                $view[$i]["Url"] 	= $rows["Url"];
		$view[$i]["anhtin"] 	= $rows["anhtin"];
		$view[$i]["trichdan"] 	= $rows["trichdan"];
		$view[$i]["ngaydang"] 	= "(".gmdate("d/m/Y, h:i, a",$rows["ngaydang"] + 7*3600).")";	
	}	
	if($ngaydang>0){
		// Đếm số trang
		$select_query = "SELECT tinid FROM tintuc WHERE sn_id = $scat";
		$sql->query($select_query);
		$count_rows = $sql->num_rows();
		$pages_number = ceil($count_rows/$new_per_page);
		$position_page = isset($_GET["position_page"]) ? $HTTP_GET_VARS["position_page"] : 1;	
		$from = $position_page ==1 ? 0 : (($new_per_page*$position_page)- $new_per_page);
		// Kết thúc đếm số trang
	$select_query = "   SELECT tinid, tieude, trichdan, ngaydang, anhtin 
                            FROM tintuc
                            WHERE ngaydang<$ngaydang AND sn_id = ".$scat." 
                            ORDER BY ngaydang DESC 
                            LIMIT $from, $new_per_page";

	$sql->query($select_query);	
            $i = 0;
            while($rows = $sql->fetch_array()){
                    $i = $i + 1;
                    $news[$i]["tinid"]          = $rows["tinid"];
                    $news[$i]["tieude"] 	= $rows["tieude"];
                    $news[$i]["anhtin"] 	= $rows["anhtin"];
                    $news[$i]["trichdan"] 	= $rows["trichdan"];
                    $news[$i]["ngaydang"] 	= "(".gmdate("d/m/Y, h:i, a",$rows["ngaydang"] + 7*3600).")";	
            }
	}
	else{
		$message = "Không có thông tin bạn yêu cầu !";
	}
    
    $select_query = "SELECT sn_id, newscat_id, sn_title FROM subnews WHERE sn_id = ".$scat." LIMIT 1";
    $sql->query($select_query);
    $result =  $sql->fetch_array();
    $newscat_id = $result['newscat_id'];
    $catname   = $result['sn_title'];
	$subsmp = array(); 
        $select_query = "SELECT * FROM subnews WHERE newscat_id = ".$newscat_id." ORDER BY sn_list,sn_title";
        $sql->query($select_query);
        $i = 0;
        while($rows = $sql->fetch_array()){
                $i = $i + 1;
                $subid                          = $rows["sn_id"];
                $subsmp[$i]["sn_id"] 		= $rows["sn_id"];
                $subsmp[$i]["sn_title"] 	= $rows["sn_title"];	
                $subsmp[$i]["newscat_id"] 	= $rows["newscat_id"];	
        }  
        
$sql->close();	
}
$title = array(	"snews" => " $catname", );

function sub_menu(){
   global $subsmp, $scat;                 
    echo '<div  class="sub-menu">';
                    echo"<ul >";
                        for($i=1; $i<=count($subsmp); $i++){
                            if($scat == $subsmp[$i]["sn_id"] ){ 
                            echo"<li class='bg-hat'><a class='clbold' href='".WEB_DOMAIN."/s".$subsmp[$i]["sn_id"]."-".cut_space(name_ascii($subsmp[$i]["sn_title"]))."/' title='".$subsmp[$i]["sn_title"]."'>".$subsmp[$i]["sn_title"]." </a></li>";
                            }
                            else{ 
                                echo"<li class='bg-hat'><a href='".WEB_DOMAIN."/s".$subsmp[$i]["sn_id"]."-".cut_space(name_ascii($subsmp[$i]["sn_title"]))."/' title='".$subsmp[$i]["sn_title"]."'>".$subsmp[$i]["sn_title"]." </a></li>";
                        }
                        }
                    echo"</ul>";
                    echo '</div>';
                    }
function publish(){
        global $catname, $scat, $view, $pages_number, $position_page, $check, $dir_imgnews1;	
echo '<div id="left_content" class="ml10">
        <div class="tieudetintuc"><h1>'.$catname.'</h1>
        </div>';
       for($i=1; $i<=count($view); $i++){
			$anhtin = $view[$i]["anhtin"] <> "" ? "<img class='img130' src='".$dir_imgnews1.$view[$i]["anhtin"]."' alt='".$view[$i]["tieude"]."' title='".$view[$i]["tieude"]."'>" : '';
		echo '  <div class="cottintuc">
                        <div class="immg">';
             	echo    $anhtin;
                echo '  </div>
                        <div class="ndtintuc">
                        <div class="tentintuc"><a href="'.WEB_DOMAIN.'/'.$view[$i]["Url"].'.htm"><b>'.$view[$i]["tieude"].'</b></a></div>
                	<span>'.strip_tags(strimString($view[$i]["trichdan"],80)).'</span>   
                        </div></div>';
		}
            echo '<div class="clear"></div>';
    if($pages_number >1 ){
            echo '<div class="paging" style="margin-top:15px;">';
                    pages_HG("/spage-".$scat."/trang-",$position_page,$pages_number);
            echo "</div>";
    }	       
echo '</div>';
echo '<div id="right_content" class="mr10">
        	<div class="cotright ">
            	<div class="tieuderight cot1">Danh mục sách</div>
             <div id="linklk" class="linklk">
                    	<ul>
                            <li><a href="#">Kiến thức làm giàu</a></li>
                            <li><a href="#">Máy tính bảng giá rẻ có ôi?</a></li>
                            <li><a href="#">Kiến thức kinh tế</a></li>
                            <li><a href="#">Kiến thức khoa học</a></li>
                            <li><a href="#">Kiến thức danh nhân</a></li>
                            <li><a href="#">Kiến thức tôn giáo</a></li>
                             <li><a href="#">Cao học kinh tế</a></li>
                             <li><a href="#">Đang chơ những tấm lòng hảo tâm</a></li>
                             <li  style="border-bottom:none;"><a href="#">Khác!!!</a></li>
                        </ul>
                    </div>   
            </div>
        	<div class="cotright ">
            	<div class="tieuderight cot1">Tài liệu kĩ năng</div>
             <div id="linklk" class="linklk">
                    	<ul>
                            <li><a href="#">Kĩ năng tự học hiệu quả</a></li>
                            <li><a href="#">Kĩ năng bán hàng</a></li>
                            <li><a href="#">Kĩ năng thương lượng</a></li>
                            <li><a href="#">Kĩ năng giải quyết vấn đề</a></li>
                            <li><a href="#">Kĩ năng tổ chức công việc</a></li>
                            <li><a href="#">Kĩ năng thuyết trình</a></li>
                             <li><a href="#">Kĩ năng tư duy  chiến lượng</a></li>
                             <li><a href="#">Kĩ năng giao tiếp</a></li>
                             <li style="border-bottom:none;"><a href="#">Kĩ năng làm việc theo nhóm</a></li>
                        </ul>
                    </div>   
            </div><!--cotright-->
            <div class="cotright">
            	<div class="tieuderight">Thông tin từ BeRichMart</div>
                <div class="noidungright">
                	<div class="tintuc"><a href="#">Mua hàng an toàn trên BeRich-Mart</a><div>Bạn muốn mua hàng và được giao hàng tận nơi?</div></div>
                    <div class="tintuc"><a href="#">Mua hàng an toàn trên BeRich-Mart</a><div>Bạn muốn mua hàng và được giao hàng tận nơi?</div></div>
                    <div class="tintuc"><a href="#">Mua hàng an toàn trên BeRich-Mart</a><div>Bạn muốn mua hàng và được giao hàng tận nơi?</div></div>
                    <div class="xemthem"><a href="#">Xem thêm</a></div>
                </div>
            </div><!--cotright-->
        </div><!--rightcontent-->';   
}
?>