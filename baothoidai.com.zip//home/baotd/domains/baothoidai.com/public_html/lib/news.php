<?php
if (!defined("qaz_wsxedc_qazxc0FD_123K")){		
		die("<a href='../index.php'>Home</a>");
}
$news = array();
$view = array();
$sub_news   = array();
$check = 0;
global $new_per_page, $newscat_full;
$newscat_id     = isset($_GET["cat"])   ? $_GET["cat"]   : (isset($_POST["cat"])  ? $_POST["cat"]  : "0");
if($hweb == "news"){
	$sql = new db_sql();
	$sql->db_connect();
	$sql->db_select();	
		$select_query = "SELECT tinid FROM tintuc WHERE newscat_id = $newscat_id";
		$sql->query($select_query);
		$count_rows = $sql->num_rows();
	$pages_number = ceil($count_rows/$new_per_page);
	$position_page = isset($_GET["position_page"]) ? $HTTP_GET_VARS["position_page"] : 1;	
	$from = $position_page ==1 ? 0 : (($new_per_page*$position_page)- $new_per_page);
	$select_query = "SELECT tinid, tieude, Url, trichdan, ngaydang, anhtin FROM tintuc";
	if($newscat_id > 0)
	$select_query .= " WHERE newscat_id = ".$newscat_id;
	$select_query .=" ORDER BY ngaydang DESC LIMIT $from, $new_per_page";
	$sql->query($select_query);
	$i = 0;
	while($rows = $sql->fetch_array()){
		$ngaydang = $rows["ngaydang"];
		$i = $i + 1;
		$view[$i]["tinid"] 	= $rows["tinid"];
		$view[$i]["tieude"] 	= $rows["tieude"];
                $view[$i]["Url"] 	= $rows["Url"];
		$view[$i]["anhtin"] 	= $rows["anhtin"];
		$view[$i]["trichdan"] 	= $rows["trichdan"];
		$view[$i]["ngaydang"] 	= "(".gmdate("d/m/Y, h:i, a",$rows["ngaydang"] + 7*3600).")";	
	}	
	if($ngaydang>0){
		// Đếm số trang
		$select_query = "SELECT tinid FROM tintuc WHERE newscat_id = $newscat_id";
		$sql->query($select_query);
		$count_rows = $sql->num_rows();
		$pages_number = ceil($count_rows/$new_per_page);
		$position_page = isset($_GET["position_page"]) ? $HTTP_GET_VARS["position_page"] : 1;	
		$from = $position_page ==1 ? 0 : (($new_per_page*$position_page)- $new_per_page);
		// Kết thúc đếm số trang
	$select_query = "SELECT tinid, tieude, trichdan, ngaydang, anhtin FROM tintuc".
	" WHERE ngaydang<$ngaydang AND newscat_id = ".$newscat_id.
	" ORDER BY ngaydang DESC LIMIT $from, $new_per_page";

	$sql->query($select_query);	
	$i = 0;
		while($rows = $sql->fetch_array()){
			$i = $i + 1;
			$news[$i]["tinid"] 	= $rows["tinid"];
			$news[$i]["tieude"] 	= $rows["tieude"];
			$news[$i]["anhtin"] 	= $rows["anhtin"];
			$news[$i]["trichdan"] 	= $rows["trichdan"];
			$news[$i]["ngaydang"] 	= "(".gmdate("d/m/Y, h:i, a",$rows["ngaydang"] + 7*3600).")";	
		}
	}
	else{
		$message = "Không có thông tin bạn yêu cầu !";
	}
        	
$select_query = "SELECT * FROM subnews WHERE newscat_id = ".$newscat_id." ORDER BY sn_list,sn_title";
$sql->query($select_query);
$i = 0;
while($rows = $sql->fetch_array()){
	$i = $i + 1;
	$subid                          = $rows["sn_id"];
	$subsmp[$i]["sn_id"] 		= $rows["sn_id"];
	$subsmp[$i]["sn_title"] 	= $rows["sn_title"];
	$subsmp[$i]["icon"]             = $rows["icon"];	
	$subsmp[$i]["newscat_id"] 	= $rows["newscat_id"];	
}  
        
$sql->close();	
}
		for($i=1; $i<=count($newscat_full); $i++)
		if($newscat_full[$i]["id"]==$newscat_id)
			$catname = $newscat_full[$i]["title"];
	$title = array(	"news" => " $catname",
 	);

function sub_menu(){
   global $subsmp;                 
    echo '<div  class="sub-menu">';
                    echo"<ul >";
                        for($i=1; $i<=count($subsmp); $i++){
                    echo"<li class='bg-hat'><a href='".WEB_DOMAIN."/s".$subsmp[$i]["sn_id"]."-".cut_space(name_ascii($subsmp[$i]["sn_title"]))."/' title='".$subsmp[$i]["sn_title"]."'>".$subsmp[$i]["sn_title"]." </a></li>";
                        }
                    echo"</ul>";
                    echo '</div>';
                    }
function publish(){
        global $subsmp, $subid, $subnews, $sn_id, $subnews_name, $news, $view, $newscat, $newscat_full, $pages_number, $position_page, $check, $dir_imgnews1;
	$newscat_id     = isset($_GET["cat"])   ? $_GET["cat"]   : (isset($_POST["cat"])  ? $_POST["cat"]  : "0");
		for($i=1; $i<=count($newscat_full); $i++)
		if($newscat_full[$i]["id"]==$newscat_id)
			$catname = $newscat_full[$i]["title"];
				$message = "".$catname."";
echo '<div id="left_content" class="ml10">
       <div class="tieudetintuc"><h1>'.$catname.'</h1></div>';
       for($i=1; $i<=count($view); $i++){
			$anhtin = $view[$i]["anhtin"] <> "" ? "<img class='img130' src='".$dir_imgnews1.$view[$i]["anhtin"]."' alt='".$view[$i]["tieude"]."' title='".$view[$i]["tieude"]."'>" : '';
		echo '  <div class="cottintuc">
                        <div class="immg">';
             	echo    $anhtin;
                echo '  </div>
                        <div class="ndtintuc">
                        <div class="tentintuc"><a href="'.WEB_DOMAIN.'/'.$view[$i]["Url"].'.htm"><b>'.$view[$i]["tieude"].'</b></a></div>
                	<span>'.strip_tags(strimString($view[$i]["trichdan"],80)).'</span>   
                        </div></div>';
		}
            echo '<div class="clear"></div>';
    if($pages_number >1 ){
            echo '<div class="paging" style="margin-top:15px;">';
                    pages_HG("/page-".$newscat_id."/trang-",$position_page,$pages_number);
            echo "</div>";
    }	       
echo '</div>';
echo '<div id="right_content" class="mr10">
        	<div class="cotright ">
            	<div class="tieuderight cot1">Danh mục sách</div>
             <div id="linklk" class="linklk">
                    	<ul>
                            <li><a href="#">Kiến thức làm giàu</a></li>
                            <li><a href="#">Máy tính bảng giá rẻ có ôi?</a></li>
                            <li><a href="#">Kiến thức kinh tế</a></li>
                            <li><a href="#">Kiến thức khoa học</a></li>
                            <li><a href="#">Kiến thức danh nhân</a></li>
                            <li><a href="#">Kiến thức tôn giáo</a></li>
                             <li><a href="#">Cao học kinh tế</a></li>
                             <li><a href="#">Đang chơ những tấm lòng hảo tâm</a></li>
                             <li  style="border-bottom:none;"><a href="#">Khác!!!</a></li>
                        </ul>
                    </div>   
            </div>
        	<div class="cotright ">
            	<div class="tieuderight cot1">Tài liệu kĩ năng</div>
             <div id="linklk" class="linklk">
                    	<ul>
                            <li><a href="#">Kĩ năng tự học hiệu quả</a></li>
                            <li><a href="#">Kĩ năng bán hàng</a></li>
                            <li><a href="#">Kĩ năng thương lượng</a></li>
                            <li><a href="#">Kĩ năng giải quyết vấn đề</a></li>
                            <li><a href="#">Kĩ năng tổ chức công việc</a></li>
                            <li><a href="#">Kĩ năng thuyết trình</a></li>
                             <li><a href="#">Kĩ năng tư duy  chiến lượng</a></li>
                             <li><a href="#">Kĩ năng giao tiếp</a></li>
                             <li style="border-bottom:none;"><a href="#">Kĩ năng làm việc theo nhóm</a></li>
                        </ul>
                    </div>   
            </div><!--cotright-->
            <div class="cotright">
            	<div class="tieuderight">Thông tin từ BeRichMart</div>
                <div class="noidungright">
                	<div class="tintuc"><a href="#">Mua hàng an toàn trên BeRich-Mart</a><div>Bạn muốn mua hàng và được giao hàng tận nơi?</div></div>
                    <div class="tintuc"><a href="#">Mua hàng an toàn trên BeRich-Mart</a><div>Bạn muốn mua hàng và được giao hàng tận nơi?</div></div>
                    <div class="tintuc"><a href="#">Mua hàng an toàn trên BeRich-Mart</a><div>Bạn muốn mua hàng và được giao hàng tận nơi?</div></div>
                    <div class="xemthem"><a href="#">Xem thêm</a></div>
                </div>
            </div><!--cotright-->
        </div><!--rightcontent-->';   
}
?>