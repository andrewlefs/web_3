<?php
if (!defined("qaz_wsxedc_qazxc0FD_123K")){		
		die("<a href='../index.php'>Trang ch&#7911;</a>");
}
$customer = array();
$view = array();
$check = 0;
$cuscat_id     = isset($_GET["cat"])   ? $_GET["cat"]   : (isset($_POST["cat"])  ? $_POST["cat"]  : "0");
if($Webdesign == "maudetail"){
	$sql = new db_sql();
	$sql->db_connect();
	$sql->db_select();	
	if(isset($_GET["id"])){
		$check = 1;
		$id = $_GET["id"];
		$select_query = "SELECT views FROM customer WHERE tinid=".$id;
		$sql->query($select_query);
		$rows = $sql->fetch_array();
		$views = intval($rows["views"]);
		$views++; 
		$update_query = "UPDATE customer SET views=$views WHERE tinid=$id";
			if(!$sql->query($update_query))
			echo 'Loi Update!';
		$select_query = "SELECT tinid, tieude, trichdan, views, noidung, ngaydang, ihome, url2, nguontin, cuscat_id FROM customer WHERE tinid = '$id'";
		$sql->query($select_query);
		$row = $sql->fetch_array();
		$ngaydang = $row["ngaydang"];
		$title 				= $row["tieude"];
		$view[1]["tinid"] 		= $row["tinid"];
		$view[1]["tieude"] 		= $row["tieude"];
		$view[1]["url2"] 		= $row["url2"];
		$view[1]["views"] 		= $row["views"];
		$view[1]["ihome"] 		= $row["ihome"];
		$view[1]["trichdan"] 	= nl2br($row["trichdan"]);
		$view[1]["noidung"] 	= nl2br($row["noidung"]);
		$view[1]["nguontin"] 	= nl2br($row["nguontin"]);
		$view[1]["ngaydang"] 	= "(".gmdate("d/m/Y, h:i, a",$row["ngaydang"] + 7*3600).")";	
	}
	else{
		$select_query = "SELECT tinid, tieude, trichdan, views, noidung, ngaydang, ihome, url2, nguontin FROM customer WHERE cuscat_id = ".$cuscat_id." ORDER BY ngaydang DESC";
		$sql->query($select_query);
		$row = $sql->fetch_array();
		$ngaydang = $row["ngaydang"];

		$view[1]["tinid"] 		= $row["tinid"];
		$view[1]["tieude"] 		= $row["tieude"];
		$view[1]["url2"] 		= $row["url2"];
		$view[1]["views"] 		= $row["views"];
		$view[1]["ihome"] 		= $row["ihome"];
		$view[1]["trichdan"] 	= nl2br($row["trichdan"]);
		$view[1]["noidung"] 	= nl2br($row["noidung"]);
		$view[1]["nguontin"] 	= nl2br($row["nguontin"]);
		$view[1]["ngaydang"] 	= "(".gmdate("d/m/Y, h:i, a",$row["ngaydang"] + 7*3600).")";	
	}
	$title = array(	"maudetail" => "Mãu website - $title",
											);
	if($ngaydang>0){
	$select_query = "SELECT tinid, tieude, trichdan, ngaydang, views, ihome FROM customer WHERE ngaydang<$ngaydang AND cuscat_id = ".$cuscat_id." ORDER BY ngaydang DESC LIMIT 0, $new_per_page";
	$sql->query($select_query);	
	$i = 0;
		while($rows = $sql->fetch_array()){
			$i = $i + 1;
			$customer[$i]["tinid"] 		= $rows["tinid"];
			$customer[$i]["tieude"] 	= $rows["tieude"];
			$customer[$i]["ihome"] 		= $rows["ihome"];
			$view[$i]["trichdan"] 		= nl2br($row["trichdan"]);
			$customer[$i]["noidung"] 	= nl2br($rows["noidung"]);
			$customer[$i]["ngaydang"] 	= "(".gmdate("d/m/Y, h:i, a",$rows["ngaydang"] + 7*3600).")";	
		}
	}
	else{
		$message = "Không có thông tin bạn yêu cầu !";
	}
	$sql->close();	
}

function maudetail_view(){
	global $customer, $view, $check, $dir_imgcustomer1, $cuscat;
	$cuscat_id     = isset($_GET["cat"])   ? $_GET["cat"]   : (isset($_POST["cat"])  ? $_POST["cat"]  : "0");		
	if(count($view)>0){
		echo "<div class=\"ziza\">";
	    echo "<span> &#9827; <a href=\"".WEB_DOMAIN."\" title=\"Trang Chủ\" rel='nofollow'>Trang Chủ</a> › <a href=\"".WEB_DOMAIN."/Mau-thiet-ke-website.htm\" title='Mẫu thiết kế website'>Mẫu thiết kế website</a></span>";
	    echo "</div>";
		echo "<h1><a href='".$_SERVER['REQUEST_URI']."' title='".$view[1]["tieude"]."'>".$view[1]["tieude"]."</a></h1>";
		echo "<div class='images_mk' style='background:url(".WEB_DOMAIN.$dir_imgcustomer1.$view[1]["ihome"].") no-repeat top left; padding-bottom:20px;'></div>";
		echo "<p>".$view[1]["noidung"]."</p>";
		echo "<div class='trangin'>";
		echo "<a rel=\"nofollow\" class='quaylai fl kc_c' href='javascript:history.back(-1)'>Trang tr&#432;ớc</a>";
			echo "<a rel=\"nofollow\" href='mailto:".$dmail."' class='mail fl kc_c' title='Gửi e-Mail'>Gửi e-Mail</a>";
			echo "<a rel=\"nofollow\" href='javascript:print()' class='fl print kc_c' title='In trang này'>In trang</a>";
			echo "<a rel=\"nofollow\" href='#' class='fl ontop kc_c' title='In trang này'>Trang đầu</a>";
			echo "<i>( Lượt xem: ".$view[1]["views"].")</i>";
		echo "</div>";
		echo "<div class='social_div'>";
			echo "<div class='social_div_150'>";		
				echo "<a rel=\"nofollow\" href=\"http://twitter.com/share\" class=\"twitter-share-button\" data-count=\"horizontal\" data-via=\"hoanggiwebsite\">Tweet</a>";
					echo "<script type=\"text/javascript\" src=\"http://platform.twitter.com/widgets.js\"></script>";
		echo "</div>";
			echo "<div class='social_div_150'>";
				echo "<g:plusone size=\"medium\"></g:plusone>";	
					echo "</div>";
		echo "</div>";
	}	
	else echo "<font face='Arial, Tahoma' size='2'>Không có dữ liệu bạn yêu cầu !</font>";	
}
?>