<?php
if (!defined("qaz_wsxedc_qazxc0FD_123K")){		
		die("<a href='../index.php'>Home</a>");
}
//Connect to database
//Var
$username_invalid 			= false;
$username_existing 			= false;
$password_invalid 			= false;
$confirm_password_invalid 	= false;
$firstname_invalid 			= false;
$email_invalid 				= false;
$email_existing				= false;
$address_invalid 			= false;
$phone_invalid 				= false;
$workphone_invalid 			= false;
$captcha_invalid			= false;
$captcha_input_invalid		= false;
$arrUserInfo = array();
$msg='';
if($_SERVER['REQUEST_METHOD']=='POST'){
	$sql = new db_sql();
	$sql->db_connect();
	$sql->db_select();
	$arrUserInfo =& $_POST;
	$arrUserInfo["user"] = strip_tags(addslashes(trim($arrUserInfo["user"])));
	if(!eregi('^[a-zA-Z0-9_]+$', $arrUserInfo["user"]))
		$username_invalid = true;
	if($arrUserInfo["user"]=='' || strlen($arrUserInfo["user"]) < 4){
		$username_invalid = true;
	}else{
		$sSQL = "SELECT memberid
			    FROM member
				WHERE user='".$arrUserInfo["user"]."'";
		$sql->query($sSQL);
		if($sql->num_rows()>0)
			$username_existing = true;
	}
	
	if($arrUserInfo["email"]=='' || !check_valid_email($arrUserInfo["email"])){
		$email_invalid = true;
	}else{
		$sSQL = "SELECT memberid
			    FROM member
				WHERE email='".$arrUserInfo["email"]."'";
		$sql->query($sSQL);
		if($sql->num_rows()>0)
			$email_existing = true;
	}
	if($arrUserInfo["pass"]=='' || strlen($arrUserInfo["user"]) < 6){
		$password_invalid = true;
		$arrUserInfo["pass"] = '';
		$arrUserInfo["repass"] = '';
	}
	if($arrUserInfo["pass"]!=$arrUserInfo["repass"]){
		$confirm_password_invalid = true;
		$arrUserInfo["pass"] = '';
		$arrUserInfo["repass"] = '';
	}
	if($arrUserInfo["fullname"]=='')
		$firstname_invalid = true;
	if($arrUserInfo["phone"]=='')
		$phone_invalid = true;
	if($arrUserInfo["workphone"]=='')
		$workphone_invalid = true;
	if($arrUserInfo["address"]=='')
		$address_invalid = true;
	
	if(!$username_invalid && !$username_existing && !$password_invalid && !$confirm_password_invalid && !$firstname_invalid && !$email_invalid && !$email_existing && !$address_invalid && !$phone_invalid && !$workphone_invalid) {
		$sSQL = "INSERT INTO member(`user`, `pass`, `fullname`, `phone`, `workphone`, `address`, `email`, `signdate`) VALUES('".$arrUserInfo["user"]."', '".$arrUserInfo["pass"]."', '".$arrUserInfo["fullname"]."', '".$arrUserInfo["phone"]."', '".$arrUserInfo["workphone"]."', '".$arrUserInfo["address"]."', '".$arrUserInfo["email"]."', ".time().")";
		$sql->query($sSQL);
	/*	ob_start();
		include "/hoanggia/register_letter.tpl";
		$mail_content = ob_get_contents();
		ob_end_clean(); 
		require_once '/lib/phpmailer/class.phpmailer.php';
		//Create mail object
		$mail    = new PHPMailer();
		$mail->From     = 'contact@hoanggia.net';
		$mail->FromName = "Công Ty công nghệ truyền thông Hoàng Gia";
		$mail->Subject  = "Thong tin tai khoan";
		$mail->MsgHTML($mail_content);
		$mail->AddAddress($arrUserInfo["email"], $arrUserInfo["fullname"]);
		$mail->Send();	*/
		redirect('/dang-ky-thanh-cong.htm');
	} else {
		if($email_invalid)
			$msg = "Xin vui lòng nhập E-mail hợp lệ.";			
		
		if($email_existing)
			$msg = "E-mail này đang được sử dụng. Xin vui lòng chọn E-mail khác.";
		
		if($phone_invalid)
			$msg = "Xin vui lòng nhập số Điện thoại của bạn.";
		
		if($workphone_invalid)
			$msg = "Xin vui lòng nhập số Điện thoại của bạn.";
			
		if($address_invalid)
			$msg = "Xin vui lòng nhập Địa chỉ của bạn.";
		if($firstname_invalid)
			$msg = "Xin vui lòng nhập Họ tên của bạn.";
		if($password_invalid)
			$msg = "Xin vui lòng nhập Mật khẩu hợp lệ.";							
		if($confirm_password_invalid)
			$msg = "Mật khẩu không chính xác. Xin vui lòng nhập lại";
		if($username_invalid)
			$msg = "Xin vui lòng nhập Tên đăng nhập hợp lệ";
		if($username_existing)
			$msg = "Tên đăng nhập này đang được sử dụng. Vui lòng chọn Tên đăng nhập khác.";
	}
	$sql->close();
}
?>