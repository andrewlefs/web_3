<?php
if (!defined("qaz_wsxedc_qazxc0FD_123K")){		
		die("<a href='../index.php'>Home</a>");
}
ini_set("SMTP","203.160.8.14");		
	if($HTTP_POST_VARS["Webdesign"] == "contact" && isset($HTTP_POST_VARS["mode"]) && $HTTP_POST_VARS["mode"]=="send"){	
		$name 		= convert_font(trim($_POST["name"]));
		$office		= convert_font(trim($_POST["office"]));
		$address	= convert_font(trim($_POST["address"]));
		$email 		= convert_font(trim($_POST["email"]));
		$tel 		= convert_font(trim($_POST["tel"]));
		$titlec 	= convert_font(trim($_POST["titlec"]));
		$content	= convert_font(trim($_POST["content"]));
		if($name 	== "") $message1 = $message1."Bạn chưa nhập họ tên ";
		if($tel 	== "") $message1 = $message1."Bạn chưa nhập điện thoại ";
		if($email 	== "") $message1 = $message1."Bạn chưa nhập email ";
		if($email !='')
			if (!eregi("^[a-zA-Z0-9_]+@[a-zA-Z0-9\-]+\.[a-zA-Z0-9\-\.]+$", $email))
				$message1 = $message1."Bạn nhập Email chưa hợp lệ ";		
		if($titlec  == "") $message1 = $message1."Bạn chưa nhập tiêu đề liên hệ ";
		if($content == "") $message1 = $message1."Bạn chưa nhập nội dung ";
		$sql = new db_sql();
		$sql->db_connect();
		$sql->db_select();	
		if($message1 ==""){	
			$name 		= convert_font(trim($_POST["name"]),2);
			$office 	= convert_font(trim($_POST["office"]),2);
			$address	= convert_font(trim($_POST["address"]),2);
			$email 		= convert_font(trim($_POST["email"]),2);
			$tel 		= convert_font(trim($_POST["tel"]),2);
			$titlec 	= convert_font(trim($_POST["titlec"]),2);
			$content	= convert_font(trim($_POST["content"]),2);
			$time = time();
			$insert_query = "INSERT INTO contact(name, office, address, email, tel, title, content, senddate) VALUES('$name', '$office', '$address', '$email', '$tel','$titlec','$content', $time)";			
			if($sql->query($insert_query)){	
                        $message = "Xin cảm ơn bạn ! Thông tin đã được gửi. ";
//                        ob_start();
//                    $mail_content = ob_get_contents();
//		    require_once '/extsource/phpmailer/class.phpmailer.php';
//                    $mail  = new PHPMailer();
//                    $body  = '<table border="0" width="100%">
//				<tr>
//                                    <td width="100">Tên khách hàng:</td>
//                                    <td>'.$name.'</td>
//				</tr>
//				<tr>
//                                    <td>Cơ quan:</td>
//                                    <td>'.$office.'</td>
//				</tr>
//				<tr>
//                                    <td>Địa chỉ liên hệ:</td>
//                                    <td>'.$address.'</td>
//				</tr>
//				<tr>
//                                    <td>Điện thoại:</td>
//                                    <td>'.$tel.'</td>
//                                <tr>
//                                    <td>Tiêu đề:</td>
//                                    <td>'.$titlec.'</td>
//				</tr>
//				</table><br>'.$content.'';
//                    $body             = eregi_replace("[\]",'',$body);
//                    
//                    $mail->IsSMTP(); 
//                    $mail->SMTPAuth   = true;                
//                    $mail->SMTPSecure = "ssl";                 
//                    $mail->Host       = "smtp.gmail.com";      
//                    $mail->Port       = 465;                 
//                    $mail->Username   = "huutiensinh@gmail.com";  
//                    $mail->Password   = "Abc12345678";          
//                    $mail->SetFrom('huutiensinh@gmail.com', 'Hoang Gia Media');
//                    $mail->AddReplyTo("huutiensinh@gmail.com","Hoang Gia Media");
//                    $mail->Subject    = "".$titlec."Khach hang lien he tai Hoanggia.net.Vn";
//                    $mail->MsgHTML($body);
//                    $address = "huutiensinh@gmail.com";
//                    $mail->AddAddress($dmail , $name);
//                    $mail->Send(); 
                    unset($name, $email, $tel, $titlec, $content, $office, $address);
                    }		
                    $sql->close();	
		}
	}
	
		$title = array(	"contact" => "".$lang['menu_cont']."",
											);	
			
function contact(){
	global $name, $email, $tel, $titlec, $content, $message1, $message, $office, $address;
	if($message!="")    echo "<div class='success'>Success: ".$message."</div>";
        if($message1!="")   echo "<div class='warning'>Warning: ".$message1."</div>";
	echo "<div class='contact'>";
	echo "<p><b>VĂN PHÒNG HÀ NỘI</b><br />Văn phòng giao dịch: Tầng 3 - Số 170 Hào Nam, Đống Đa, TP. Hà Nội <br />";
	echo " Điện thoại: 043 550 1189, Fax: 043 513 4663<br />";
	echo " Holine: &nbsp; &nbsp; &nbsp; &nbsp;090 550 1189<br /></p>";
	echo "<p><b>Liên hệ thanh toán:</b><br />Đơn vị: Công ty TNHH Công nghệ truyền thông Hoàng Gia.<br /> Số tài khoản: 222-10-00005533-5 <br />Sở giao dịch: Ngân Hàng Đầu Tư Và Phát Triển Việt Nam, Chi nhánh Thanh Xuân. <br />Vui lòng gọi cho chúng tôi theo số 090 550 1189  để xác nhận thông tin ngay sau khi chuyển tiền. Trân trọng Cám ơn</p>";
	echo "</div>";
	echo "<br/>";
        echo '<p>IP Của bạn là: '.$_SERVER['REMOTE_ADDR'].'</p><br/>';
	echo "<div class='form_contact'>";
		echo "<form action='".WEB_DOMAIN."/lien-he.htm' method='post' enctype='multipart/form-data'>";
			echo "<div class='colum_form'>";
				echo "<div class='header_form'> Tên khách hàng: </div>";
					echo "<div class='input_form'><input class='winput' id='name' name='name' value='".$name."'/></div>";
						echo "</div>";
			echo "<div class='colum_form'>";
				echo "<div class='header_form'> Cơ quan: </div>";
					echo "<div class='input_form'><input class='winput' name='office' id='office' value='".$office."'/></div>";
						echo "</div>";
			echo "<div class='colum_form'>";
				echo "<div class='header_form'> Địa chỉ liên hệ:</div>";
					echo "<div class='input_form'><input class='winput' name='address' id='address' value='".$address."'/></div>";
						echo "</div>";
			echo "<div class='colum_form'>";
				echo "<div class='header_form'> Điện thoại: </div>";
					echo "<div class='input_form'> <input class='winput' name='tel' id='tel' value='".$tel."' /></div>";
						echo "</div>";
			echo "<div class='colum_form'>";
				echo "<div class='header_form'> Email: </div>";
					echo "<div class='input_form'><input class='winput' name='email' id='email' value='".$email."'/></div>";
						echo "</div>";
			echo "<div class='colum_form'>";
				echo "<div class='header_form'> Tiêu đề: </div>";
					echo "<div class='input_form'><input class='winput' name='titlec' id='titlec' value='".$titlec."'/></div>";
						echo "</div>";
			echo "<div class='colum_form'>";
				echo "<div class='header_form'> Nội dung:</div>";
					echo "<div class='input_form'><textarea class='nd' name='content' cols='36' rows='10' >".$content."</textarea></div>";
						echo "</div>";
			echo "<div class='colum_form'>";
				echo "<div class='header_form'> &nbsp  </div>";
					echo "<div class='input_form'><input class='btn_contact' type='submit' value='Gửi liên hệ' />";
						echo "<input name='Webdesign' type='hidden' value='contact'>";
						echo "<input name='mode' type='hidden' value='send'>";
						echo "</div>";
						echo "</div>";
	echo "</form>";
echo "</div>";
}
?>