<?
if (!defined('qaz_wsxedc_qazxc0FD_123K')){		
		die("<a href='../index.php'>Home</a>");
}

function do_html_header($title){
		global $Auth, $message, $hweb;
		include("new/header.tpl");
		}
function do_html_footer(){
		include("new/footer.tpl");
		}
    function menu_top (){
        global $menu_top, $hweb, $newscat_id ;
        echo '  <div class="navmenu" >
        	<ul class="width960">';
       if($hweb=="index"){ echo "<li class='current'><a href='".WEB_DOMAIN."'>Trang nhất</a></li>"; }
       else{ echo "<li><a href='".WEB_DOMAIN."'>Trang nhất</a></li>"; }
                        
                for($i=1; $i<=count($menu_top); $i++){
            if($newscat_id == $menu_top[$i]["id"] ){ 
            echo '      <li class="current"><a href="'.WEB_DOMAIN.'/c'.$menu_top[$i]["id"].'-'.cut_space(name_ascii($menu_top[$i]["title"])).'/" title="'.$menu_top[$i]["title"].'">'.$menu_top[$i]["title"].'</a></li>'; 
        
        }
       else{ echo '      <li><a href="'.WEB_DOMAIN.'/c'.$menu_top[$i]["id"].'-'.cut_space(name_ascii($menu_top[$i]["title"])).'/" title="'.$menu_top[$i]["title"].'">'.$menu_top[$i]["title"].'</a></li>';  }
       
      }
        echo '  </ul>
                </div>';
        }

function new_event(){
	global $new_event, $dir_imgnews1 ;
        echo'<div id="slide"> 
                    <div id="slide_top">';
                    $tt= 0 ;
                    for($i=1; $i<=count($new_event); $i++){
          		$anhtin = "<img src='".$dir_imgnews1.$new_event[$i]["anhtin"]."' width='500' height='240' alt='".$new_event[$i]["tieude"]."' title='".$new_event[$i]["tieude"]."'/>";
                        $tt=$tt+1;
                	echo '<div id="'.$tt.'" class="img">'.$anhtin.'<br /><div class="summary-hotnews"><a href="'.WEB_DOMAIN.'/'.$new_event[$i]["Url"].'.htm">'.strip_tags(cut_str($new_event[$i]["tieude"],100)).'</a><div>'.strip_tags(cut_str($new_event[$i]["trichdan"],250)).'</div></div></div>';
			}
                    echo '</div>
                    <div id="slide_bottom">
                        <ul>';
                        $ttt= 0;
                        for($i=1; $i<=count($new_event); $i++){
          		$anhtin = "<img src='".$dir_imgnews1."_thumbs/".$new_event[$i]["anhtin"]."_t.jpg' alt='".$new_event[$i]["tieude"]."' title='".$new_event[$i]["tieude"]."'/>";
                        $ttt=$ttt+1;
                        if($ttt == 1){ 
                            $class1 = 'class="active"';
                        } else {
                          $class1 = '';  
                        }
                	echo '<li><a title="#'.$ttt.'" '.$class1.'>'.$anhtin.'</a></li>';
			}
                        echo '</ul>
                    </div>
               </div>';
}

function last_new_top_vews(){
   global $new_top_view, $dir_imgnews1 ;                 
   echo '<div class="tieuderight mgr-bt10">Tin đọc nhiều</div>';
    echo '<ul>';
       for($i=1; $i<=count($new_top_view); $i++){  
            echo '<li class="li-xemnhieu">
        <img class="anhxemnhieu" border="0" alt="'.$new_top_view[$i]["tieude"].'"  title="'.$new_top_view[$i]["tieude"].'" src="'.$dir_imgnews1.'_thumbs/'.$new_top_view[$i]["anhtin"].'_t.jpg">        
        <a href="'.WEB_DOMAIN.'/'.$new_top_view[$i]["Url"].'.htm" title="'.$new_top_view[$i]["tieude"].'">'.$new_top_view[$i]["tieude"].'</a></li>';
            }          
    echo '</ul>';
   
}


function last_new_139(){
   global $new_139, $dir_imgnews1 ;                 
   echo '<div class="tieuderight">Tin giải trí</div>
         <div class="noidungright">';
    echo '<ul>';
       for($i=1; $i<=count($new_139); $i++){  
            echo '<li>
        <img class="anhtin" border="0" alt="'.$new_139[$i]["tieude"].'" src="'.$dir_imgnews1.$new_139[$i]["anhtin"].'">        
        <a href="'.WEB_DOMAIN.'/'.$new_139[$i]["Url"].'.htm">'.cut_str($new_139[$i]["tieude"],70) .'</a></li>';
            }          
    echo '</ul>
        <p align="center"><embed height="300" width="192" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" src="http://www.lasta.com.vn/Files/Advertises/sms6365.swf" play="true" loop="true" menu="true"></embed></p>	
      </div>        
        ';
   
}


function top_yahoo(){
	global $yahoo;
        for($i=1; $i<=count($yahoo); $i++){       
        echo "<a rel=\"nofollow\" href='ymsgr:sendIM?".$yahoo[$i]["nickname"]."' title='Liên hệ hỗ trợ trực tuyến với ".$yahoo[$i]["yahooname"]."'><img src='http://opi.yahoo.com/online?u=".$yahoo[$i]["nickname"]."' alt='Liên hệ với chúng tôi' /></a>";
        }	
}

function slider(){
	global $slider, $dir_imgslider1;
    echo "<ul id='slider1Content'>";
		for($i=1; $i<=count($slider); $i++){
		echo "<li class='slider1Image'>";
		echo "<a href='".$slider[$i]["link"]."'><img src='".$dir_imgslider1.$slider[$i]["logo"]."' alt='".$slider[$i]["content"]."' /></a>";
		echo "<span class='".$slider[$i]["position"]."'><strong>Hoang Gia INC</strong><br />".$slider[$i]["content"]."</span></li>";
		}
		echo "<div class='clear slider1Image'></div>";
        echo "</ul>";
}


function body_faq(){
	global $faq, $new_50, $khach_tags,$weblist_tags, $cat,$pro2;	
			for($i=1; $i<=count($khach_tags); $i++){
			echo "<a href='".WEB_DOMAIN."/khach-hang/".$khach_tags[$i]["tinid"]."-".cut_space(name_ascii($khach_tags[$i]["tieude"])).".htm' title='".$khach_tags[$i]["tieude"]."'>".$khach_tags[$i]["tieude"]."</a>, ";
			}
	for($i=1; $i<=count($weblist_tags); $i++){
			echo "<a href='".WEB_DOMAIN."/thiet-ke-web/".$weblist_tags[$i]["web_id"]."-".cut_space(name_ascii($weblist_tags[$i]["web_name"])).".htm' title='".$weblist_tags[$i]["web_name"]."'>".$weblist_tags[$i]["web_name"]."</a>, ";
	}
	for($i=1; $i<=count($faq); $i++){ 
		echo "<a href='".WEB_DOMAIN."/hoi-dap/".$faq[$i]["faqid"]."/".cut_space(name_ascii($faq[$i]["faqtitle"])).".htm' title='".$faq[$i]["faqtitle"]."'>".$faq[$i]["faqtitle"]."</a>, ";
	}
	for($i=1; $i<=count($new_50); $i++){
		echo "<a href='".WEB_DOMAIN."/new/".$new_50[$i]["tinid"]."-".cut_space(name_ascii($new_50[$i]["tieude"])).".htm' title='".$new_50[$i]["tieude"]."'>".$new_50[$i]["tieude"]."</a>, ";	
	}
///////
for($i=1; $i<=count($pro2); $i++){
		echo "<a href='".WEB_DOMAIN."/giai-phap/".$pro2[$i]["sanphamid"]."/".cut_space(name_ascii($pro2[$i]["ten"])).".htm'>".$pro2[$i]["ten"]."</a>, ";	
	}
}

function info_hn(){	
	echo "<ul>";
		//echo "<li>Giấy CN ĐKKD số 0103596514 do sở KH & ĐT TP. Hà Nội cấp tháng 3 Năm 2009.</li>";
                //echo "<li>Địa chỉ: Số 35 Ngõ 1/62/26 phố Bùi Xương Trạch, P. Khương Đình, Q.Thanh Xuân, TP. Hà Nội.</li>";
		echo "<li>VPGD: Số 12, Ngõ 1/2, phố Hồ Đắc Di, Đống Đa, Hà Nội</li>";
		echo "<li>Điện thoại: 043 550 1189, Fax: 0435 335 448, Hotline: 090 550 1189</li>";
                echo "<li>E-mail: info@hoanggia.net, sale@hoanggia.net</li>";
	echo "</ul>"; 
}
function seolink(){  ////adv/([0-9]+)(.*)
global $linkseo; 
			for($i=1; $i<=count($linkseo); $i++){
			$url1 = "http://".$linkseo[$i]["linkweb"]."";
			echo "<a target='_blank' href='".$url1."' title='".$linkseo[$i]["keyword"]."'>".$linkseo[$i]["keyword"].",</a>\n";
			}
}

function nav_footer(){ 
creatLOG($_SERVER['REMOTE_ADDR']);
global $counter;
            echo "COPYRIGHT © 2008 - <script type='text/javascript'>d = new Date();y = d.getFullYear();document.write(y);</script> HOANG GIA INC &nbsp; &nbsp;";
            echo "<a href='".WEB_DOMAIN."/Rss/' class='link_footer' style='color: #f4fd03;' title='Kênh thông tin Hoàng Gia'>HGRSS</a> <span> | </span>";
            echo "<a href='".WEB_DOMAIN."/lien-ket.htm' class='link_footer' title='Liên kết website' rel=\"nofollow\">Liên kết</a> <span> | </span>";
            echo "<a href='".WEB_DOMAIN."/sodoweb.htm' class='link_footer' title='Site maps' rel=\"nofollow\">Site maps</a> <span> | </span>";
            echo "<a href='".WEB_DOMAIN."/download.htm' class='link_footer' title='Download' rel=\"nofollow\"> Download </a> <span> | </span>";
     	    echo "<span> Online: ".getTOTAL()."</span> <span> | </span>";
            echo "<span> Total visitors: ".number_format($counter,0)."</span> &nbsp; &nbsp;"; 
}
				
function logo_link(){
	global $logo_link;
		echo "<ul id='mycarousel' class='jcarousel-skin-tango'>";
	for($i=1; $i<=count($logo_link); $i++){
		$tt = $tt + 1;
		echo "<li><a target='_blank' href='".$logo_link[$i]["nguontin"]."'><img src='uploads/imgcustomer/".$logo_link[$i]["anhtin"]."' height='75' alt='' /></a></li>";
	}
		echo "</ul>";
}
function logos($lr,$nlogo){
	global $logo, $dir_imglogos1, $logo_position;
	$isLeft = 0;
	$isRight = 0;
	for($i=1;$i<count($logo);$i++){
		if($isLeft == 0) $isLeft = ($logo[$i]["position"] == "left" ? 1:0);
		if($isRight == 0) $isRight = ($logo[$i]["position"] == "right" ? 1:0);
	}
	
	if(count($logo)>0){
		$num_logo = count($logo)>$nlogo ? $nlogo : count($logo);
		if(($isLeft == 1) && ($lr == "left")){	
			for($i=1; $i<=count($logo); $i++){
				if($logo[$i]["position"] == "left"){
					$logoimg = "<a href='".$logo[$i]["link"]."' target='_blank' title='".$logo[$i]["link"]."'><img src='".$dir_imglogos1.$logo[$i]["logo"]."' class='anhleft'></a>\n";
					echo $logoimg;
				}
			}
		}
		//Rendering Logos at the Right
		if(($isRight == 1) && ($lr == "right")){
			for($i=1; $i<=count($logo); $i++){
				if($logo[$i]["position"] == "right"){
					$logoimg = "<a href='".$logo[$i]["link"]."' target='_blank' title='".$logo[$i]["link"]."'><img src='".$dir_imglogos1.$logo[$i]["logo"]."' class='anhright'></a>\n";
					echo $logoimg;
				}
			}
		}
	}
	else{}	
}
?>