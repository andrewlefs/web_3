<?php
if (!defined("qaz_wsxedc_qazxc0FD_123K")){		
		die("<a href='../index.php'>Trang ch&#7911;</a>");
}
$faq_d 	= array();
$sql = new db_sql();
$sql->db_connect();
$sql->db_select();
if(isset($_GET["id"]) && $HTTP_GET_VARS["Webdesign"] == "faqdetail"){
	$id = isset($_GET["id"]) && is_numeric($_GET["id"]) ? $_GET["id"] : 0;
	$select_query = "SELECT faqtitle, question, answer FROM faq WHERE faqid = $id";		
	$sql->query($select_query);							
	if($row = $sql->fetch_array()){
		$title 	= $row["faqtitle"];
		$faq_d["faqtitle"] 	= $row["faqtitle"];
		$faq_d["question"] 	= $row["question"];
		$faq_d["answer"] 	= nl2br($row["answer"]);
	}
		$title = array(	"faqdetail" => "Hỏi đáp | $title",
 	);
	$sql->close();		
}
function detail_faq(){
	global $faq_d;
	if(count($faq_d)>0){
	echo "<h1>CHI TIẾT HỎI &amp; &#272;ÁP</h1>";			
	echo "<p><b>".$faq_d["faqtitle"]."</b></p> ";
	echo "<p><strong> Hỏi : </strong>".$faq_d["question"]."</p>";
	echo "<p><strong> Đáp : </strong>".$faq_d["answer"]."</p>";
	echo "<p align='right'>";
	echo "<a href='javascript:history.go(-1);'>[Về trang trước]</a>&nbsp;";
	echo "<a href='javascript:print()'>[Tạo trang in]</a>";			
	}else echo "<br><font face='Arial, Tahoma' size='2'>Không có dữ liệu bạn yêu cầu !</font>";		
}
?>