<?php
if (!defined("qaz_wsxedc_qazxc0FD_123K")){		
		die("<a href='../index.php'>Home</a>");
}
$news = array();
$view = array();
$check = 0;
$pattern = '/^84(\d+)/i';
$replacement = '0$1';

global $newscat_full,$lang;
if($hweb == "newdetail"){
	$sql = new db_sql();
	$sql->db_connect();
	$sql->db_select();	
	if(isset($_GET["id"])){
		$id = $_GET["id"];
                $btID = preg_replace($pattern, $replacement, $id);
		$select_query = "SELECT views, newscat_id, sn_id FROM tintuc WHERE Url = '$btID' ";
		$sql->query($select_query);
		$rows = $sql->fetch_array();
		$newscat_id = $rows["newscat_id"];
                $sn_id      = $rows["sn_id"];
                $views = intval($rows["views"]);
		$views++; 
		$update_query = "UPDATE tintuc SET views=$views WHERE Url = '$btID'";
			if(!$sql->query($update_query))
			echo 'Loi Update!';
		$select_query = "SELECT tinid, tieude, trichdan, Url, noidung, tags, views, ngaydang, anhtin, nguontin, newscat_id FROM tintuc WHERE Url = '$btID'";
		$sql->query($select_query);
		$row = $sql->fetch_array();
		$ngaydang = $row["ngaydang"];
		$title 		= $row["tieude"];
                $tinid 		= $row["tinid"];
                $view[1]["Url"] 	= $row["Url"];
		$view[1]["tieude"] 	= $row["tieude"];
		$view[1]["anhtin"] 	= $row["anhtin"];
		$view[1]["views"] 	= $row["views"];
		$view[1]["tags"] 	= $row["tags"];
		$view[1]["trichdan"] 	= $row["trichdan"];
		$view[1]["noidung"] 	= $row["noidung"];
		$view[1]["nguontin"] 	= $row["nguontin"];
		$view[1]["ngaydang"] 	= "(".gmdate("d/m/Y, h:i, a",$row["ngaydang"] + 7*3600).")";	
	}
	else{
		$message = "Không có thông tin bạn yêu cầu !";	
	}

	if($ngaydang>0){
	$select_query = "SELECT tinid, tieude, Url, ngaydang FROM tintuc WHERE ngaydang<$ngaydang AND newscat_id = ".$newscat_id." ORDER BY ngaydang DESC LIMIT 0, $new_per_page";
	$sql->query($select_query);	
	$i = 0;
		while($rows = $sql->fetch_array()){
			$i = $i + 1;
			$news[$i]["tinid"] 	= $rows["tinid"];
			$news[$i]["tieude"] 	= $rows["tieude"];
			$news[$i]["Url"] 	= $rows["Url"];
			$news[$i]["ngaydang"] 	= "(".gmdate("d/m/Y, h:i, a",$rows["ngaydang"] + 7*3600).")";	
		}
	}
	else{
		$message = "Không có thông tin bạn yêu cầu !";
	}

$select_query = "SELECT * FROM subnews WHERE newscat_id = ".$newscat_id." ORDER BY sn_list,sn_title";
$sql->query($select_query);
$i = 0;
while($rows = $sql->fetch_array()){
	$i = $i + 1;
	$subsmp[$i]["sn_id"] 		= $rows["sn_id"];
	$subsmp[$i]["sn_title"] 	= $rows["sn_title"];
	$subsmp[$i]["icon"]             = $rows["icon"];	
	$subsmp[$i]["newscat_id"] 	= $rows["newscat_id"];	
}
	$sql->close();	
}
    for($i=1; $i<=count($newscat_full); $i++)
    if($newscat_full[$i]["id"]==$newscat_id){
		$catname    = $newscat_full[$i]["title"];
	}
$title = array("newdetail" => $title ." | ".$catname." | Hoàng Gia",
 	);

if(isset($HTTP_POST_VARS["mode"]) && $HTTP_POST_VARS["mode"]=="send"){	
		$FullName 	= $_POST["FullName"];
		$Email 		= $_POST["Email"];
		$Content	= $_POST["Content"];
		$New_ID		= $tinid;
                if($Email 	== "") $message_c1 = $message_c1."Bạn chưa nhập email ";
		if($Email !='')
			if (!eregi("^[a-zA-Z0-9_]+@[a-zA-Z0-9\-]+\.[a-zA-Z0-9\-\.]+$", $Email))
				$message_c1 = $message_c1."Bạn nhập Email chưa hợp lệ ";
		if($Content == "") $message_c1 = $message_c1."Bạn chưa nhập nội dung";
		$sql = new db_sql();
		$sql->db_connect();
		$sql->db_select();	
		if($message_c1 ==""){	
			$FullName 	= $_POST["FullName"];
			$Email 		= $_POST["Email"];
			$Content	= $_POST["Content"];
			$New_ID		= $tinid;
			$insert_query = "INSERT INTO new_binhluan(New_ID, Content, FullName, Email, Publish, CreateDate) VALUES ($New_ID, '".$Content."', '".$FullName."', '".$Email."', 0, NOW())";
                        if($sql->query($insert_query)){	
				$message_c = "Gửi thành công.";
				unset($FullName, $Email);
			}		
			$sql->close();	
		}
	}

function sub_menu(){
   global $subsmp, $subid, $subnews, $sn_id;                 
    echo '<div  class="sub-menu">';
                    echo"<ul >";
                        for($i=1; $i<=count($subsmp); $i++){
                            if($sn_id == $subsmp[$i]["sn_id"] ){ 
                            echo"<li class='bg-hat'><a class='clbold' href='".WEB_DOMAIN."/s".$subsmp[$i]["sn_id"]."-".cut_space(name_ascii($subsmp[$i]["sn_title"]))."/' title='".$subsmp[$i]["sn_title"]."'>".$subsmp[$i]["sn_title"]." </a></li>";
                            }
                            else{ 
                                echo"<li class='bg-hat'><a href='".WEB_DOMAIN."/s".$subsmp[$i]["sn_id"]."-".cut_space(name_ascii($subsmp[$i]["sn_title"]))."/' title='".$subsmp[$i]["sn_title"]."'>".$subsmp[$i]["sn_title"]." </a></li>";
                        }
                        }
                    echo"</ul>";
                    echo '</div>';
                    }
function publish (){
    global $news, $view, $check, $catname, $dmail, $newscat_title,$lang, $newscat_id, $dir_imgnews1;		
    $web_images = $view[1]["anhtin"] <> "" ? "<img src='".$dir_imgnews1.$view[1]["anhtin"]."' style='float:left; padding-right:10px;'width=\"140\" alt='".$view[1]["tieude"]."' title='".$view[1]["tieude"]."'>" : '';
    $url_link = WEB_DOMAIN.'/'.$view[1]["Url"].HTML;
   if(count($view)>0){
    echo ' <div id="content-650" class="ml10">
        <h1>'.$view[1]["tieude"].'</h1>     
    <div class="fbrecommend"> 
    <div id="fbleft"></div> 
    <div id="fbright"></div> 

    <div id="fbrecommend">
    <div id="ggppit"><a data-pin-config="beside" target="_blank" href="//pinterest.com/pin/create/button/?url='.$url_link.'&media='.$dir_imgnews1.$view[1]["anhtin"].'&description='.$view[1]["tieude"].'/'.$view[1]["trichdan"].'" data-pin-do="buttonPin" ><img src="//assets.pinterest.com/images/pidgets/pin_it_button.png" /></a>
        </div>
        <div id="ggptt"> 
    <a href="http://twitter.com/share" class="twitter-share-button" data-count="horizontal">Tweet</a>
    <script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script>
    </div>
        <div id="ggplus">
               <g:plusone size="medium"></g:plusone>
        </div>
        <div id="fbbox">
          <div class="fb-like" data-send="true" data-width="400" data-show-faces="false"></div> 
        </div> 
        <div style="clear:left"></div> </div> </div>   
    <div class="cottintuc"
          <div class="ndtintuc">';
            echo $web_images ;
            echo 'Cập nhật |<i>'.$view[1]["ngaydang"].'</i> <br /><strong>'.strip_tags($view[1]["trichdan"])."</strong><br />";
            echo replace_badword($view[1]["noidung"]);
        echo "<div class='tag-parent'>";
                echo "<div class='tag-pos wp-650'>";
                echo "<h3 class='tag-text'>";
                $tags = explode(',', $view[1]["tags"]);
		foreach($tags as $tag)
                        {
			echo "<a href='".WEB_DOMAIN."/tags/key-".$tag."' title='".$tag."'>".$tag."</a>";
                        echo ", ";
                        }
                        echo '<a href="'.WEB_DOMAIN.'/c'.$newscat_id.'-'.cut_space_hg(name_ascii($catname)).'/" title="'.$catname.'">'.$catname.'</a>';
                echo "</h3>";
                echo "</div>";
                echo "</div>";
echo '<div class="cleaner"></div>';
          echo "<div class='trangin wp-650'>";
			echo "<a class='nguon2 fl kc_n' rel='nofollow' href='#'>Nguồn:".$view[1]["nguontin"]."</a>";
			echo "<a class='quaylai fl kc_c' rel='nofollow' href='javascript:history.back(-1)'>Trang tr&#432;&#7899;c</a>";
			echo "<a href='mailto:".$dmail."' rel='nofollow' class='mail fl kc_c' title='G&#7917;i e-Mail'>G&#7917;i e-Mail</a>";
			echo "<a href='javascript:print()' rel='nofollow' class='fl print kc_c' title='In trang này'>In trang</a>";
			echo "<a href='#' class='ontop fl kc_c' rel='nofollow' title='On top'>Trang &#273;&#7847;u</a>";
			echo "<i>( Lượt xem: ".$view[1]["views"].")</i>";
		echo "</div>";
echo '<div class="cleaner"></div>';
ECHO '<div class="fb-comments" data-href="'.$url_link.'" data-num-posts="5" data-width="650"></div>';
//echo '<div class="tieudetintuc"><h2>Gửi Bình Luận:</h2></div>';	
//        if($message_c!="")    echo "<div class='success-c'>Success: ".$message_c."</div>";
//        if($message_c1!="")   echo "<div class='warning-c'>Warning: ".$message_c1."</div>";	 
//       echo"<div class='binh-luan'>";
//	   echo"<form action='".$url_link."' method='post' enctype='multipart/form-data' name='add' id='add'>";  
//	   echo"<div class='colum_bl'>
//                <label>Họ và Tên:</label>
//                    <input name='FullName' value='".$FullName."'/>
//                        </div>";
//           echo"<div class='colum_bl'>
//                <label>Email:</label>
//                    <input name='Email' value='".$Email."'/>
//                        </div>";
//	   
//	   echo"<div class='colum_bl'>
//                <label>Nội dung:</label>
//                    <textarea name='Content' cols='36' rows='10'>".$Content."</textarea>
//                        </div>";
//	   
//	   echo '<div class="colum_bt">
//                <input type="submit" value="Gửi đi" />
//                <input name="mode" type="hidden" value="send">
//                <input type="hidden" name="New_ID" value="'.$tinid.'"/>';
//       echo"</div>";
//    echo"</form>";
//    echo"</div>"; 
   }
   else {
       
     echo $message; 
   }
    if(count($news)>0){
        echo '<div class="tieudetintuc"><h2>Các '.$catname.' tin khác:</h2></div>
                <div id="linklk" class="other-news">
                    <ul>';  
                        for($i=1; $i<=count($news); $i++)
                        echo '<li><a href="'.WEB_DOMAIN.'/'.$news[$i]["Url"].'.htm" title="'.$news[$i]["tieude"].'">'.$news[$i]["tieude"].'</a>&nbsp;'.$news[$i]["ngaydang"].'</li>';
         echo '     </ul>
          <div class="readmore"><a href="'.WEB_DOMAIN.'/c'.$newscat_id.'-'.cut_space_hg(name_ascii($catname)).'/">Xem thêm</a></div>
        </div>';
    }   else{
    }
    echo '</div></div>';
echo '

    
    <!--left_content-->
    <div id="right_300" class="mr10">
      <div class="cotright ">
        <div class="tieuderight cot1">Danh mục sách</div>
        <div id="linklk" class="linklk">
          <ul>
            <li><a href="#">Kiến thức làm giàu</a></li>
            <li><a href="#">Máy tính bảng giá rẻ có ôi?</a></li>
            <li><a href="#">Kiến thức kinh tế</a></li>
            <li><a href="#">Kiến thức khoa học</a></li>
            <li><a href="#">Kiến thức danh nhân</a></li>
            <li><a href="#">Kiến thức tôn giáo</a></li>
            <li><a href="#">Cao học kinh tế</a></li>
            <li><a href="#">Đang chơ những tấm lòng hảo tâm</a></li>
            <li  style="border-bottom:none;"><a href="#">Khác!!!</a></li>
          </ul>
        </div>
      </div>
      <!--cotright-->
      <div class="cotright ">
        <div class="tieuderight cot1">Tài liệu kĩ năng</div>
        <div id="linklk" class="linklk">
          <ul>
            <li><a href="#">Kĩ năng tự học hiệu quả</a></li>
            <li><a href="#">Kĩ năng bán hàng</a></li>
            <li><a href="#">Kĩ năng thương lượng</a></li>
            <li><a href="#">Kĩ năng giải quyết vấn đề</a></li>
            <li><a href="#">Kĩ năng tổ chức công việc</a></li>
            <li><a href="#">Kĩ năng thuyết trình</a></li>
            <li><a href="#">Kĩ năng tư duy  chiến lượng</a></li>
            <li><a href="#">Kĩ năng giao tiếp</a></li>
            <li style="border-bottom:none;"><a href="#">Kĩ năng làm việc theo nhóm</a></li>
          </ul>
        </div>
      </div>
      <!--cotright-->
      <div class="cotright">
        <div class="tieuderight">Thông tin từ BeRichMart</div>
        <div class="noidungright">
          <div class="tintuc"><a href="#">Mua hàng an toàn trên BeRich-Mart</a>
            <div>Bạn muốn mua hàng và được giao hàng tận nơi?</div>
          </div>
          <div class="tintuc"><a href="#">Mua hàng an toàn trên BeRich-Mart</a>
            <div>Bạn muốn mua hàng và được giao hàng tận nơi?</div>
          </div>
          <div class="tintuc"><a href="#">Mua hàng an toàn trên BeRich-Mart</a>
            <div>Bạn muốn mua hàng và được giao hàng tận nơi?</div>
          </div>
          <div class="xemthem"><a href="#">Xem thêm</a></div>
        </div>
      </div>
      <!--cotright--> 
            <!--cotright-->
      <div class="cotright">
        <div class="tieuderight">Thông tin từ BeRichMart</div>
        <div class="fb-like-box" data-href="http://www.facebook.com/baothoidai" data-width="300" data-send="true" data-stream="false" data-show-faces="true" data-header="true"></div>

        </div>
      </div>
      <!--cotright-->
    </div>
    <!--rightcontent--> ';
}
function newdetail_view(){
	global $news, $view, $check, $catname, $dmail, $newscat_title,$lang, $newscat_id, $dir_imgnews1;		
	if(count($view)>0){
		$web_images = $view[1]["anhtin"] <> "" ? "<img src='".$dir_imgnews1.$view[1]["anhtin"]."' style='float:left; padding-right:10px;'width=\"140\" height=\"80\" alt='".$view[1]["tieude"]."' title='".$view[1]["tieude"]."'>" : '';
		echo "<div class=\"ziza\">";
		echo "<span> &#9827; <a rel='nofollow' href='".WEB_DOMAIN."' title='Trang Chủ'>Trang Chủ</a> › <a href='".WEB_DOMAIN."/category/".$newscat_id."/".cut_space(name_ascii($catname)).".htm' title='".$catname."'>".$catname."</a></span>";
	    echo "</div>";
	    echo "<h1><a href='".WEB_DOMAIN."/".$newscat_id."/".$view[1]["tinid"]."/".cut_space(name_ascii($view[1]["tieude"])).".htm' title='".$view[1]["tieude"]."'>".$view[1]["tieude"]."</a></h1>";
		echo $web_images;
		echo $view[1]["trichdan"]."<br />";
		echo $view[1]["noidung"];
			echo "<div class='social_div'>";
			echo "<div class='social_div_150'>";		
				echo "<a href=\"http://twitter.com/share\" rel=\"nofollow\" class=\"twitter-share-button\" data-count=\"horizontal\" data-via=\"hoanggiwebsite\">Tweet</a>";
					echo "<script type=\"text/javascript\" src=\"http://platform.twitter.com/widgets.js\"></script>";
			echo "</div>";	
			echo "<div class='social_div_150'>";
				echo "<g:plusone size=\"medium\"></g:plusone>";	
			echo "</div>";			
		echo "</div>";
		echo "<div class='social_div'>";
		echo "<div class='tags'>";
		echo "&nbsp;&nbsp; &nbsp; Tags:";
		$tags = explode(',', $view[1]["tags"]);
		foreach($tags as $tag)
		{
			echo "<a href='".WEB_DOMAIN."/tags/key-".$tag."' title='".$tag."'>".$tag."</a>, ";
		}
			echo "<a href='".WEB_DOMAIN."/category/".$newscat_id."/".cut_space(name_ascii($catname)).".htm' title='".$catname."'>".$catname."</a>";
		echo "</div>";

		echo "<div class='trangin'>";
			echo "<a class='nguon2 fl kc_c' href='#' rel='nofollow'>Nguồn:".$view[1]["nguontin"]."</a>";
			echo "<a class='quaylai fl kc_c' rel='nofollow' href='javascript:history.back(-1)'>Trang tr&#432;&#7899;c</a>";
			echo "<a href='mailto:".$dmail."' rel='nofollow' class='mail fl kc_c' title='G&#7917;i e-Mail'>G&#7917;i e-Mail</a>";
			echo "<a href='javascript:print()' rel='nofollow' class='fl print kc_c' title='In trang này'>In trang</a>";
			echo "<a href='#' class='fl ontop kc_c' rel='nofollow' title='In trang này'>Trang &#273;&#7847;u</a>";
			echo "<i>( Lượt xem: ".$view[1]["views"].")</i>";
		echo "</div>";
		echo "</div>";
	}

}
?>