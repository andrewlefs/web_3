<?php
if (!defined("qaz_wsxedc_qazxc0FD_123K")){		
		die("<a href='http://hoanggia.net'>Home</a>");
}
$mauweb = array();
	if($Webdesign == "mauweb"){
	$sql = new db_sql();
	$sql->db_connect();
	$sql->db_select();	
	$count_rows = $sql->count_rows("customer");
	$pages_number = ceil($count_rows/$mauweb_page);
	$position_page = isset($_GET["position_page"]) ? $HTTP_GET_VARS["position_page"] : 1;	
	$from = $position_page ==1 ? 0 : (($mauweb_page*$position_page)- $mauweb_page);
	$select_query = "SELECT tinid, tieude, trichdan, ngaydang, url2, nguontin, anhtin 
					FROM customer 
					ORDER BY ngaydang DESC LIMIT $from, $mauweb_page";
	
	$sql->query($select_query);
	$i = 0;
	while($rows = $sql->fetch_array()){
		$ngaydang = $rows["ngaydang"];
		$i = $i + 1;
		$mauweb[$i]["tinid"] 		= $rows["tinid"];
		$mauweb[$i]["tieude"] 		= $rows["tieude"];
		$mauweb[$i]["anhtin"] 		= $rows["anhtin"];
		$mauweb[$i]["trichdan"] 	= nl2br($rows["trichdan"]);
		$mauweb[$i]["nguontin"] 	= nl2br($rows["nguontin"]);
		$mauweb[$i]["url2"] 		= nl2br($rows["url2"]);
		$mauweb[$i]["ngaydang"] 	= "(".gmdate("d/m/Y, h:i, a",$rows["ngaydang"] + 7*3600).")";
	}	
	$sql->close();	
	
	$title = array(	"mauweb" => "mẫu thiết kế website, mẫu website - Hoang Gia INC",
 	);
}			
function mauweb_view(){
	global $mauweb, $pages_number, $position_page, $check, $dir_imgcustomer1;
	if(count($mauweb)>0){
	echo "<a href='".WEB_DOMAIN."/khach-hang-rss' rel='nofollow' title='Thiết kế website, ".$mauweb[$i]["tieude"]."'><img src='".TPL_LINK."/images/rss_icon.png' alt='rss' height='19' title='rss' style='float:left; padding-left:3px; padding-right:3px'/></a><h1><a href='".WEB_DOMAIN."/Mau-website-dep.htm' title='Mẫu thiết kế website'>Mẫu thiết kế website</a></h1>";
	echo "<p>Những mẫu thiết kế mới nhất</p>"; 
	echo "<div class='mau_web'>"; 		
		for($i=1; $i<=count($mauweb); $i++){
			$anhtin = $mauweb[$i]["anhtin"] <> "" ? "<img src='".WEB_DOMAIN.$dir_imgcustomer1.$mauweb[$i]["anhtin"]."' alt='".$mauweb[$i]["tieude"]."' width='150'  style='float:left; padding-left:3px; padding-right:3px' title='".$mauweb[$i]["tieude"]."'>" : '';
			echo "<div class='mau_box'>";
			echo $anhtin ;
			echo "<p><a class='title_new2' href='".WEB_DOMAIN."/Mau-thiet-ke-website/".$mauweb[$i]["tinid"]."-".cut_space(name_ascii($mauweb[$i]["tieude"])).".htm' title='Mẫu Website, ".$mauweb[$i]["tieude"]."'>".$mauweb[$i]["tieude"]."</a></p>";
			echo "</div>";
		}
	}
	echo "</div>"; 
		
	echo "<div class='phantrang'>";
	if($pages_number >1 ){
         	echo "<div class='paging01'>";
			pages_browser("/Mau-thiet-ke/page/",$position_page,$pages_number);
			echo "</div>";
			}
	echo "</div>";
}
?>