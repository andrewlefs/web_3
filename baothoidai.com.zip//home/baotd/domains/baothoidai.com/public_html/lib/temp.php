<?php

if (!defined("qaz_wsxedc_qazxc0FD_123K")){		
		die("<a href='../index.php'>Trang ch&#7911;</a>");
}
$pro = array();
$sql = new db_sql();
$sql->db_connect();
$sql->db_select();
$Webdesign = $HTTP_GET_VARS["Webdesign"];
if(isset($_GET["cat"]) && !isset($_GET["subcat"]) && $HTTP_GET_VARS["Webdesign"] == "temp"){
	$catid = isset($_GET["cat"]) && is_numeric($_GET["cat"]) ? $_GET["cat"] : 0;
	$subcatid = 0;
	for($i=1; $i<=count($cat); $i++)
		if($cat[$i]["catid"]==$catid)
			$catname = $cat[$i]["catname"];
			
	$select_query = "SELECT sanphamid FROM sanpham WHERE catid = $catid";
	$sql->query($select_query);		
	$count_rows = $sql->num_rows();
	$message = "<p align='left' class='title_20' height='55'>".$catname."";
	$rows_per_page_of_product = is_numeric($rows_per_page_of_product) && $rows_per_page_of_product>0 ? $rows_per_page_of_product : 1;
	$position_page = isset($HTTP_GET_VARS["position_page"]) && is_numeric($HTTP_GET_VARS["position_page"])  ? $HTTP_GET_VARS["position_page"]:1; 
	$position_page = isset($_POST["position_page"]) ? $_POST["position_page"] : $position_page ;		
	$pages_number = ceil($count_rows/$rows_per_page_of_product);
	$from = $position_page ==1 ? 0 : (($rows_per_page_of_product*$position_page)- $rows_per_page_of_product);
	$select_query = "SELECT sanphamid, ten, anh FROM sanpham WHERE catid = $catid ORDER BY ten LIMIT $from, $rows_per_page_of_product";				
	$sql->query($select_query);
	$i=0;
	while($row = $sql->fetch_array()){
		$i=$i+1;
		$pro[$i]["sanphamid"] 	= $row["sanphamid"];
		$pro[$i]["ten"] 		= $row["ten"];
		$pro[$i]["anh"] 		= $row["anh"];
	}
	$sql->close();
}
else
	if(isset($_GET["cat"]) && isset($_GET["subcat"])){
		$catid 		= isset($_GET["cat"]) 		&& is_numeric($_GET["cat"]) 	? $_GET["cat"] 		: 0;
		$subcatid 	= isset($_GET["subcat"]) 	&& is_numeric($_GET["subcat"]) 	? $_GET["subcat"] 	: 0;
		for($i=1; $i<=count($cat); $i++)
		if($cat[$i]["catid"]==$catid){
			$cat_id = $cat[$i]["catid"];
			$catname = $cat[$i]["catname"];
		}
		for($i=1; $i<=count($subcat); $i++)
		if($subcat[$i]["subcatid"]==$subcatid)
			$subcatname = $subcat[$i]["subcatname"];
		$select_query = "SELECT sanphamid FROM sanpham WHERE catid = $catid AND subcatid = $subcatid";
		$sql->query($select_query);		
		$count_rows = $sql->num_rows();
		$message = "<p align='left' class='title_20' height='55'><a href='index.php?Webdesign=product&cat=".$cat_id."'>".$catname."</a> >> ".$subcatname."có <font color='#FF0000'>".$count_rows."</font> Mẫu";
		$rows_per_page_of_product = is_numeric($rows_per_page_of_product) && $rows_per_page_of_product>0 ? $rows_per_page_of_product : 1;
		$position_page = isset($HTTP_GET_VARS["position_page"]) && is_numeric($HTTP_GET_VARS["position_page"])  ? $HTTP_GET_VARS["position_page"]:1; 
		$position_page = isset($_POST["position_page"]) ? $_POST["position_page"] : $position_page ;	
		$pages_number = ceil($count_rows/$rows_per_page_of_product);
		$from = $position_page ==1 ? 0 : (($rows_per_page_of_product*$position_page)- $rows_per_page_of_product);
		$select_query = "SELECT sanphamid, ten, anh FROM sanpham WHERE catid = $catid AND subcatid = $subcatid ORDER BY ten LIMIT $from, $rows_per_page_of_product";				
		$sql->query($select_query);
		$i=0;
		while($row = $sql->fetch_array()){
			$i=$i+1;
			$pro[$i]["sanphamid"] 	= $row["sanphamid"];
			$pro[$i]["ten"] 		= $row["ten"];		
			$pro[$i]["anh"] 		= $row["anh"];
		}
		$sql->close();		
}
function list_product(){
	global $count_rows, $pro, $dir_imgproducts1, $message, $catname, $subcatname, $position_page, $pages_number, $catid, $subcatid;
	if(count($pro)>0)
	{
echo "<table width='98%' border='0' cellpadding='0' cellspacing='0' >";
echo "<tr>";
echo "<td height='55'>$message</td>";
echo "</tr>";
echo "</table>";
	echo "<table border='0' cellpadding='0' cellspacing='0' width='98%'>";
			echo "<tr>";
		for($i=1; $i<=count($pro); $i++){		
		$proimg1 = "<a href='index.php?Webdesign=tempdetail&id=".$pro[$i]["sanphamid"]."'><img src='".$dir_imgproducts1.$pro[$i]["anh"]."' align='center' width ='120' border='0'></a>\n";
		echo "<td width='35%' align='center' valign='top' class='product_name'>";
		echo "<a href='index.php?Webdesign=tempdetail&id=".$pro[$i]["sanphamid"]."'>".$pro[$i]["ten"]."</a><br>";
		echo $proimg1;
		echo "</TD>";

			if(($i+1)<=count($pro)){
			$proimg2 = "<a href='index.php?Webdesign=tempdetail&id=".$pro[$i+1]["sanphamid"]."'><img src='".$dir_imgproducts1.$pro[$i+1]["anh"]."' align='center' width = '120' border='0' ></a>\n";
			echo "<td width='35%' class='product_name' align='center' valign='top'>";
			echo "<a href='index.php?Webdesign=tempdetail&id=".$pro[$i+1]["sanphamid"]."'>".$pro[$i+1]["ten"]."</a><br>";
			echo $proimg2;
			echo "</TD>";
			}
				if(($i++)<=count($pro)){
				$proimg3 = "<a href='index.php?Webdesign=tempdetail&id=".$pro[$i+1]["sanphamid"]."'><img src='".$dir_imgproducts1.$pro[$i+1]["anh"]."' align='center' width = '120' border='0' ></a>\n";
				echo "<td width='35%' class='product_name' align='center' valign='top'>";
				echo "<a href='index.php?Webdesign=tempdetail&id=".$pro[$i+1]["sanphamid"]."'>".$pro[$i+1]["ten"]."</a><br>";
				echo $proimg3;
				echo "</TD>";	
		}
		echo "</tr>";
		$i++;
		}		
		echo "</table>";
		echo "<table width='98%' align='center'>";
		echo "<tbody>";
		echo "<tr>";
		if($catid!=0 && $subcatid==0 && $pages_number>1){
			echo "<td class='browser' bgcolor='whitesmoke' width='100%' height='20'>";
			pages_browser("index.php?Webdesign=product&cat=".$catid."&position_page=",$position_page,$pages_number);
			echo "</td>";
		}else
			if($catid!=0 && $subcatid!=0 && $pages_number>1){
				echo "<td class='browser' bgcolor='whitesmoke' width='100%' height='20'>";
				pages_browser("index.php?Webdesign=product&cat=".$catid."&subcat=".$subcatid."&position_page=",$position_page,$pages_number);
				echo "</td>";
			}		
		echo "</tr>";
		echo "</tbody>";
		echo "</table>";
	}
	else{
		if ($catname!='' && $subcatname=='' && !is_string($_GET["subcat"]))
			echo "<br><font face='Arial, Tahoma' size='2'>Danh mục '<strong>".$catname."</strong>' đang cập nhật sản phẩm</font>";
		else
			if ($catname!='' && $subcatname !='')
				echo "<br><font face='Arial, Tahoma' size='2'>Danh mục ' <strong>".$catname."/".$subcatname."</strong> ' đang cập nhật sản phẩm</font>";
			else
				echo "<br><font face='Arial, Tahoma' size='2'>Không có dữ liệu bạn yêu cầu !</font>";
	}	
}
?>