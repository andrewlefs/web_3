<?php
if (!defined("qaz_wsxedc_qazxc0FD_123K")){		
		die("<a href='../index.php'>Trang ch&#7911;</a>");
}
$pro_detail = array();
$sql = new db_sql();
$sql->db_connect();
$sql->db_select();
if(isset($_GET["id"]) && $HTTP_GET_VARS["Webdesign"] == "tempdetail"){
	$id = isset($_GET["id"]) && is_numeric($_GET["id"]) ? $_GET["id"] : 0;
		$select_query = "SELECT views FROM sanpham WHERE sanphamid=".$id;
		$sql->query($select_query);
		$rows = $sql->fetch_array();
		$views = intval($rows["views"]);
		$views++; 
		$update_query = "UPDATE sanpham SET views=$views WHERE sanphamid=$id";
			if(!$sql->query($update_query))
			echo 'Loi Update!';	
	$select_query = "SELECT sanphamid, catid, ten, anh, views, gia, mota, thongso FROM sanpham WHERE sanphamid = $id";		
	$sql->query($select_query);							
	if($row = $sql->fetch_array()){
		$pro_detail["sanphamid"] 	= $row["sanphamid"];
		$pro_detail["catid"] 		= $row["catid"];
		$pro_detail["ten"] 		= $row["ten"];
		$pro_detail["anh"] 		= $row["anh"];
		$pro_detail["views"] 		= $row["views"];
		$pro_detail["gia"] 		= $row["gia"];
		$pro_detail["mota"] 		= $row["mota"];
		$pro_detail["thongso"] 		= $row["thongso"];
		$title                          = $row["ten"];
                $titleascii                     = name_ascii($row["ten"]);
		
	}
		$title = array(	"tempdetail" => "$title , $titleascii",
			);	
	$sql->close();
	
	for($i=1; $i<=count($cat); $i++)
		if($cat[$i]["catid"]==$pro_detail["catid"]){
			$pro_detail["catid"] = $cat[$i]["catid"];
			$pro_detail["catname"] = $cat[$i]["catname"];
		}
}
function detail_view(){
	global $pro_detail, $dir_imgproducts1, $catname ;	
	if(count($pro_detail)>0){
        $web_images = $pro_detail["anh"] <> "" ? "<img src='".WEB_DOMAIN.$dir_imgproducts1.$pro_detail["anh"]."' style='float:left; padding-right:10px;'width=\"140\" height=\"80\" alt='".$pro_detail["ten"]."' title='".$pro_detail["ten"]."'>" : '';
		////
		echo "<div class=\"ziza\">";
	    echo "<span> &#9827; <a href=\"".WEB_DOMAIN."\" title=\"Trang Chủ\" rel='nofollow'>Trang Chủ</a> › <a href=\"".WEB_DOMAIN."/goi-website\" title=\"Thiết kế website\">Gói website</a></span>";
	    echo "</div>";
	    echo "<h1><a href='".$_SERVER['REQUEST_URI']."' title='".$pro_detail["ten"]."'>".$pro_detail["ten"]."</a></h1>";
            echo "".$web_images."";	
            echo "".$pro_detail["mota"]."";
		echo "".$pro_detail["thongso"]."";
		echo "<div class='trangin'>";
			echo "<a class='quaylai fl kc_c' href='javascript:history.back(-1)'>Trang tr&#432;ớc</a>";
			echo "<a href='mailto:".$dmail."' class='mail fl kc_c' title='Gửi e-Mail'>Gửi e-Mail</a>";
			echo "<a href='javascript:print()' class='fl print kc_c' title='In trang này'>In trang</a>";
			echo "<a href='#' class='fl ontop kc_c' title='In trang này'>Trang đầu</a>";
			echo "<a href='#' class='fl ontop kc_c'><i>( Lượt xem: ".$pro_detail["views"].")</i></a>";
			echo "</div>";
		echo "<div class='social_div'>";
			echo "<div class='social_div_150'>";		
				echo "<a href=\"http://twitter.com/share\" class=\"twitter-share-button\" data-count=\"horizontal\" data-via=\"hoanggiwebsite\">Tweet</a>";
					echo "<script type=\"text/javascript\" src=\"http://platform.twitter.com/widgets.js\"></script>";
		echo "</div>";					
		echo "</div>";
		////
}else echo "<br><font face='Arial, Tahoma' size='2'>Không có dữ liệu bạn yêu cầu !</font>";
		
}

?>