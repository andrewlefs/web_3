<?php
/* 
------------------
Language: Vietnamese
------------------
*/
$lang = array();

$lang['menu_home'] = 'Trang Chủ';
$lang['menu_intro'] = 'Giới Thiệu';
$lang['menu_news'] = 'Tin Tức';
$lang['menu_pro'] = 'Sản Phẩm';
$lang['menu_cus'] = 'khách Hàng';
$lang['menu_cont'] = 'Thiết kế website Hoàng Gia - From Liên Hệ';
// Tiêu đề web cho các trang tĩnh
$lang['home_title'] 	= 'Tin tức tổng hợp – Thông tin mọi lúc, mọi nơi tới mọi người, mọi nhà';
$lang['listweb_title'] 	= 'Thiết kế website, Thiết kế web, Công ty thiết kế web';

$lang['ycseo'] = 'Phiếu yêu cầu seo website';
$lang['list_sp'] = 'Danh Mục Sản Phẩm';
$lang['list_serv'] = 'Dịch Vụ';
$lang['new_pro'] = 'Sản Phẩm Mới';
$lang['link_web'] = 'Liên Kết Website';
$lang['search'] = 'Tìm Kiếm';
$lang['new_pro'] = 'Sản Phẩm Mới';
$lang['list_da'] = 'Dự Án Tiêu Biểu';
$lang['list_ht'] = 'Hỗ Trợ Trực Tuyến';
$lang['list_tk'] = 'Lượt Truy Cập';
$lang['list_qc'] = 'Quảng Cáo';
$lang['menu_news_detail'] = 'Tin Chi Tiết';

$lang['list_ltc'] = 'Lượt truy cập';
$lang['list_vist'] = 'Đang online';

$lang['trang_trc'] = 'Trang Trước';
$lang['trang_tiep'] = 'Trang tiep';
$lang['_PREVIOUS_PAGE'] = 'Trang Trước';
$lang['_SEND_MAIL'] 	= 'Gửi Email';
$lang['_PRINT_PAGE'] 	= 'In Trang';
$lang['_ON_TOP'] 		= 'Lên Trên';

//// message
$lang['_MESSAGE_NO_DATA'] 		= 'Không có dữ liệu bạn yêu cầu !.';

$lang['gui_eml'] = 'Gửi Email';
$lang['in_trang'] = 'In Trang';
$lang['Trang_dau'] = 'Trang Đầu';
$lang['page'] = 'Trang';
$lang['tin_khac'] = 'Các Tin Khác';
$lang['ng_dang'] = 'Ngày Đăng';
$lang['nguon'] = 'Nguồn Tin';
$lang['search_sp'] = 'Sản Phẩm Tìm Thấy';
$lang['search_value_name'] = 'Nhập từ cần tìm';
$lang['search_value_dm'] = '--- chọn danh mục ---';

$lang['name_custom'] = 'Tên : ';
$lang['web_custom'] = 'Website : ';
$lang['address_custom'] = 'Địa chỉ : ';
$lang['tel_custom'] = 'Điện thoại : ';
$lang['name_kh'] = 'Người liên hệ : ';
$lang['form_kh'] = 'Để biết thêm, xin vui lòng liên hệ theo mẫu sau : ';
$lang['office_kh'] = 'Cơ quan :  ';
$lang['address_kh'] = 'Địa chỉ liên hệ : ';
$lang['mail_kh'] = 'Email :  ';
$lang['title_kh'] = 'Tiêu đề : ';
$lang['content_kh'] = 'Nội dung : ';
$lang['sent_kh'] = 'Gửi liên hệ  ';

$lang['pro_ct'] = 'Chi tiết sản phẩm  ';
$lang['name_pro'] = 'Tên sản phẩm : ';
$lang['price_pro'] = 'Giá sản phẩm : ';
$lang['bhanh_pro'] = 'Bảo hành : ';
$lang['kho_pro'] = 'Kho : ';
$lang['buy_pro'] = 'Mua hàng : ';
$lang['mota_pro'] = 'Mô tả ';
$lang['thgso_pro'] = 'Thông số kỹ thuật ';
$lang['more'] = 'Xem tiếp ';

?>