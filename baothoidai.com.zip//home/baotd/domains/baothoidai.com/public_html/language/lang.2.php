<?php
/* 
------------------
Language: English
------------------
*/
$lang = array();

$lang['menu_home'] = 'Home';
$lang['menu_intro'] = 'About Us';
$lang['menu_news'] = 'News';
$lang['menu_pro'] = 'Product';
$lang['menu_cus'] = 'Customer';
$lang['menu_cont'] = 'Contact Us';

$lang['list_sp'] = 'List Product';
$lang['list_serv'] = 'Service';
$lang['new_pro'] = 'New Product';
$lang['link_web'] = 'Links Website';
$lang['search'] = 'Search';
$lang['list_da'] = 'Typical Projects';
$lang['list_ht'] = 'Online Support';
$lang['list_tk'] = 'Visitors Counter';
$lang['list_qc'] = 'Advertisement';
$lang['menu_news_detail'] = 'News Detail';

$lang['list_ltc'] = 'Total visistors';
$lang['list_vist'] = 'Online';

$lang['trang_trc'] = 'Previous Page';
$lang['gui_eml'] = 'Send Email';
$lang['in_trang'] = 'Print Page';
$lang['Trang_dau'] = 'Top Page';
$lang['page'] = 'Page';
$lang['tin_khac'] = 'Other News';
$lang['ng_dang'] = 'Update';
$lang['nguon'] = 'Source file';
$lang['search_sp'] = 'Products Search';
$lang['search_value_name'] = 'Import form to find';
$lang['search_value_dm'] = '--- Select a categroy ---';

$lang['name_custom'] = 'Name : ';
$lang['web_custom'] = 'Website : ';
$lang['address_custom'] = 'Address : ';
$lang['tel_custom'] = 'Telephone : ';
$lang['name_kh'] = 'Contact name : ';
$lang['form_kh'] = 'For more, please contact in the following pattern : ';
$lang['office_kh'] = 'Office :  ';
$lang['address_kh'] = 'Contact address : ';
$lang['mail_kh'] = 'Email :  ';
$lang['title_kh'] = 'Title : ';
$lang['content_kh'] = 'Content : ';
$lang['sent_kh'] = 'Sent contact  ';


$lang['pro_ct'] = 'Detail Product : ';
$lang['name_pro'] = 'Name Product : ';
$lang['price_pro'] = 'Price Product :';
$lang['bhanh_pro'] = 'Warranty : ';
$lang['kho_pro'] = 'Warehouse : ';
$lang['buy_pro'] = 'Buy : ';
$lang['mota_pro'] = 'Description';
$lang['thgso_pro'] = 'Specifications ';
$lang['more'] = 'More';
?>